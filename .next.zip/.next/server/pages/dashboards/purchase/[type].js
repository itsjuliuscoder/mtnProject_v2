"use strict";
(() => {
var exports = {};
exports.id = 200;
exports.ids = [200];
exports.modules = {

/***/ 1543:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _src_components_forms_fb_elements_CustomForm__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1443);
/* harmony import */ var react_spinners_BeatLoader__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3060);
/* harmony import */ var react_spinners_BeatLoader__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_spinners_BeatLoader__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_src_components_forms_fb_elements_CustomForm__WEBPACK_IMPORTED_MODULE_2__]);
_src_components_forms_fb_elements_CustomForm__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];








const steps = (/* unused pure expression or super */ null && (["Account", "Transaction PIN", "Finish"]));
function getServerSideProps({
  query
}) {
  // if query object was received, return it as a router prop:
  if (query.Slug) {
    return {
      props: {
        router: {
          query
        }
      }
    };
  } // obtain employeeId elsewhere, redirect or fallback to some default value:

  /* ... */


  return {
    props: {
      router: {
        query: {
          Slug: 8432
        }
      }
    }
  };
}

const Purchase = () => {
  const [activeStep, setActiveStep] = react__WEBPACK_IMPORTED_MODULE_0___default().useState(0);
  const [amount, setAmount] = react__WEBPACK_IMPORTED_MODULE_0___default().useState("");
  const {
    0: isloading,
    1: setIsloading
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true);
  const [phone, setPhonenumber] = react__WEBPACK_IMPORTED_MODULE_0___default().useState("");
  const [type, setType] = react__WEBPACK_IMPORTED_MODULE_0___default().useState("");
  const [paymentType, setPaymentType] = react__WEBPACK_IMPORTED_MODULE_0___default().useState("");
  const [walletOperator, setWalletOperator] = react__WEBPACK_IMPORTED_MODULE_0___default().useState("");
  const [amountTP, setAmountTP] = react__WEBPACK_IMPORTED_MODULE_0___default().useState(0);
  const [userData, setUserData] = react__WEBPACK_IMPORTED_MODULE_0___default().useState("");
  const [skipped, setSkipped] = react__WEBPACK_IMPORTED_MODULE_0___default().useState(new Set());
  const [paymentDesc, setPaymentDesc] = react__WEBPACK_IMPORTED_MODULE_0___default().useState("");
  const [pin, setPin] = react__WEBPACK_IMPORTED_MODULE_0___default().useState("");
  const [subType, setSubType] = react__WEBPACK_IMPORTED_MODULE_0___default().useState("");
  const [dataServices, setDataServices] = react__WEBPACK_IMPORTED_MODULE_0___default().useState("");
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    const currentUser = JSON.parse(localStorage.getItem("userData")); //const token = localStorage.getItem("userToken");
    // setAccessToken(token);

    setUserData(currentUser);
    fetchType();
    getAllServices();
  }, []);

  const fetchType = () => {
    console.log("this is the subscription type", (next_router__WEBPACK_IMPORTED_MODULE_4___default().query.type));
    setSubType((next_router__WEBPACK_IMPORTED_MODULE_4___default().query.type));
  };

  react__WEBPACK_IMPORTED_MODULE_0___default().useEffect(() => {
    setTimeout(() => setIsloading(false), 7000);
  });

  const getAllServices = () => {
    // setIsloading(true);
    const headers = {
      Accept: "application/json" // Authorization: accessToken ? accessToken : "No Auth"

    };
    axios__WEBPACK_IMPORTED_MODULE_5___default()({
      method: 'get',
      url: 'https://mtn-backend-api-service.herokuapp.com/v1/wallet/getAllProducts',
      headers
    }).then(function (response) {
      // console.log("this is the data serviced data -->", response.data);
      // setIsloading(false);
      if (response.data.statusCode === "000") {
        console.log("this is the data serviced data -->", response.data.data.others);
        let daily = response.data.data.others.daily;
        let weekend = response.data.data.others.weekend;
        let weekly = response.data.data.others.weekly;
        let days = response.data.data.others.days;
        let monthly = response.data.data.others.monthly;
        const respData = daily.concat(weekend, weekly, days, monthly);
        console.log("this is the respData -->", respData);
        setDataServices(respData); // setUserResponseData(response.data.payload);
        //setBalanceAmount(response.data.payload.wallet_balance);
        //setPinStatus(response.data.payload.isPin);
        // setDataServices(response.data.data);
      } else {
        console.log("this is the response gotten", response);
      }
    }).catch(error => {
      //setIsloading(false);
      console.log("this is the error response gotten", error); //setErrorResponse("Invalid Login Credentials");

      setTimeout(setEmptyAlert, 5000);
    });
  };

  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.Fragment, {
    children: isloading ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx((react_spinners_BeatLoader__WEBPACK_IMPORTED_MODULE_3___default()), {
      color: "#000",
      loading: isloading,
      cssOverride: {
        margin: '22em auto',
        width: '10%',
        display: 'block'
      },
      size: 30
    }) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(_src_components_forms_fb_elements_CustomForm__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
      data: userData,
      acctype: subType,
      services: dataServices
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Purchase);
});

/***/ }),

/***/ 5692:
/***/ ((module) => {

module.exports = require("@mui/material");

/***/ }),

/***/ 8442:
/***/ ((module) => {

module.exports = require("@mui/material/styles");

/***/ }),

/***/ 2167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 2296:
/***/ ((module) => {

module.exports = require("formik");

/***/ }),

/***/ 562:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 4365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 3060:
/***/ ((module) => {

module.exports = require("react-spinners/BeatLoader");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 5609:
/***/ ((module) => {

module.exports = require("yup");

/***/ }),

/***/ 3590:
/***/ ((module) => {

module.exports = import("react-toastify");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [639,664,726,761,423,443], () => (__webpack_exec__(1543)));
module.exports = __webpack_exports__;

})();