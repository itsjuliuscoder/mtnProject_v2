"use strict";
(() => {
var exports = {};
exports.id = 888;
exports.ids = [888,469];
exports.modules = {

/***/ 5600:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _app)
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
;// CONCATENATED MODULE: external "next/head"
const head_namespaceObject = require("next/head");
var head_default = /*#__PURE__*/__webpack_require__.n(head_namespaceObject);
// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(6022);
// EXTERNAL MODULE: external "@mui/material/styles"
var styles_ = __webpack_require__(8442);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
;// CONCATENATED MODULE: external "@mui/material/CssBaseline"
const CssBaseline_namespaceObject = require("@mui/material/CssBaseline");
var CssBaseline_default = /*#__PURE__*/__webpack_require__.n(CssBaseline_namespaceObject);
;// CONCATENATED MODULE: external "@emotion/react"
const react_namespaceObject = require("@emotion/react");
// EXTERNAL MODULE: external "@emotion/cache"
var cache_ = __webpack_require__(1913);
var cache_default = /*#__PURE__*/__webpack_require__.n(cache_);
;// CONCATENATED MODULE: external "stylis-plugin-rtl"
const external_stylis_plugin_rtl_namespaceObject = require("stylis-plugin-rtl");
var external_stylis_plugin_rtl_default = /*#__PURE__*/__webpack_require__.n(external_stylis_plugin_rtl_namespaceObject);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: ./src/theme/RTL.js







const styleCache = () => cache_default()({
  key: "rtl",
  prepend: true,
  // We have to temporary ignore this due to incorrect definitions
  // in the stylis-plugin-rtl module
  // @see https://github.com/styled-components/stylis-plugin-rtl/issues/23
  stylisPlugins: [(external_stylis_plugin_rtl_default())]
});

const RTL = props => {
  const {
    children,
    direction
  } = props;
  (0,external_react_.useEffect)(() => {
    document.dir = direction;
  }, [direction]);

  if (direction === "rtl") {
    return /*#__PURE__*/jsx_runtime_.jsx(react_namespaceObject.CacheProvider, {
      value: styleCache(),
      children: children
    });
  }

  return /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
    children: children
  });
};

/* harmony default export */ const theme_RTL = (RTL);
;// CONCATENATED MODULE: ./src/theme/ComponentOverRide.js
const components = {
  MuiCssBaseline: {
    styleOverrides: {
      "*": {
        boxSizing: "border-box"
      },
      html: {
        height: "100%",
        width: "100%"
      },
      body: {
        height: "100%",
        margin: 0,
        padding: 0
      },
      "#root": {
        height: "100%"
      },
      "*[dir='rtl'] .buyNowImg": {
        transform: "scaleX(-1)"
      },
      ".buyNowImg": {
        position: "absolute",
        right: "-44px",
        top: "-18px",
        width: "143px",
        height: "175px"
      },
      ".MuiCardHeader-action": {
        alignSelf: "center !important"
      },
      ".scrollbar-container": {
        borderRight: "0 !important"
      },
      "*[dir='rtl'] .welcomebg:before": {
        backgroundPosition: "top -24px left -9px !important"
      }
    }
  },
  MuiContainer: {
    styleOverrides: {
      root: {
        paddingLeft: "15px !important",
        paddingRight: "15px !important",
        maxWidth: "1600px"
      }
    }
  },
  MuiButton: {
    styleOverrides: {
      root: {
        textTransform: "none",
        boxShadow: "none",
        "&:hover": {
          boxShadow: "none"
        }
      }
    }
  },
  MuiListItem: {
    styleOverrides: {
      root: {
        borderRadius: "9px"
      }
    }
  },
  MuiCard: {
    styleOverrides: {
      root: {
        borderRadius: "20px",
        padding: "14px",
        margin: "15px",
        boxShadow: "0px 7px 30px 0px rgba(90, 114, 123, 0.11)"
      }
    }
  },
  MuiListItemIcon: {
    styleOverrides: {
      root: {
        minWidth: "40px"
      }
    }
  },
  MuiGridItem: {
    styleOverrides: {
      root: {
        paddingTop: "30px",
        paddingLeft: "30px !important"
      }
    }
  },
  MuiLinearProgress: {
    styleOverrides: {
      root: {
        backgroundColor: "#ecf0f2",
        borderRadius: "6px"
      }
    }
  },
  MuiMenuItem: {
    styleOverrides: {
      root: {
        borderRadius: "0"
      }
    }
  },
  MuiChip: {
    styleOverrides: {
      root: {
        fontWeight: "500",
        fontSize: "0.75rem"
      }
    }
  }
};
/* harmony default export */ const ComponentOverRide = (components);
;// CONCATENATED MODULE: external "lodash"
const external_lodash_namespaceObject = require("lodash");
var external_lodash_default = /*#__PURE__*/__webpack_require__.n(external_lodash_namespaceObject);
;// CONCATENATED MODULE: ./src/theme/Shadows.js
const shadows = ["none", "0px 2px 3px rgba(0,0,0,0.10)", "0 0 1px 0 rgba(0,0,0,0.31), 0 2px 2px -2px rgba(0,0,0,0.25)", "0 0 1px 0 rgba(0,0,0,0.31), 0 3px 4px -2px rgba(0,0,0,0.25)", "0 0 1px 0 rgba(0,0,0,0.31), 0 3px 4px -2px rgba(0,0,0,0.25)", "0 0 1px 0 rgba(0,0,0,0.31), 0 4px 6px -2px rgba(0,0,0,0.25)", "0 0 1px 0 rgba(0,0,0,0.31), 0 4px 6px -2px rgba(0,0,0,0.25)", "0 0 1px 0 rgba(0,0,0,0.31), 0 4px 8px -2px rgba(0,0,0,0.25)", "1px 2px 10px rgba(0,0,0,0.08)", "0 0 1px 0 rgba(0,0,0,0.31), 0 6px 12px -4px rgba(0,0,0,0.25)", "0 0 1px 0 rgba(0,0,0,0.31), 0 7px 12px -4px rgba(0,0,0,0.25)", "0 0 1px 0 rgba(0,0,0,0.31), 0 6px 16px -4px rgba(0,0,0,0.25)", "0 0 1px 0 rgba(0,0,0,0.31), 0 7px 16px -4px rgba(0,0,0,0.25)", "0 0 1px 0 rgba(0,0,0,0.31), 0 8px 18px -8px rgba(0,0,0,0.25)", "0 0 1px 0 rgba(0,0,0,0.31), 0 9px 18px -8px rgba(0,0,0,0.25)", "0 0 1px 0 rgba(0,0,0,0.31), 0 10px 20px -8px rgba(0,0,0,0.25)", "0 0 1px 0 rgba(0,0,0,0.31), 0 11px 20px -8px rgba(0,0,0,0.25)", "0 0 1px 0 rgba(0,0,0,0.31), 0 12px 22px -8px rgba(0,0,0,0.25)", "0 0 1px 0 rgba(0,0,0,0.31), 0 13px 22px -8px rgba(0,0,0,0.25)", "0 0 1px 0 rgba(0,0,0,0.31), 0 14px 24px -8px rgba(0,0,0,0.25)", "0 0 1px 0 rgba(0,0,0,0.31), 0 16px 28px -8px rgba(0,0,0,0.25)", "0 0 1px 0 rgba(0,0,0,0.31), 0 18px 30px -8px rgba(0,0,0,0.25)", "0 0 1px 0 rgba(0,0,0,0.31), 0 20px 32px -8px rgba(0,0,0,0.25)", "0 0 1px 0 rgba(0,0,0,0.31), 0 22px 34px -8px rgba(0,0,0,0.25)", "0 0 1px 0 rgba(0,0,0,0.31), 0 24px 36px -8px rgba(0,0,0,0.25)"];
/* harmony default export */ const Shadows = (shadows);
;// CONCATENATED MODULE: ./src/theme/Typoraphy.js
const typography = {
  fontFamily: "'DM Sans', sans-serif",
  body1: {
    fontWeight: 400 // or 'bold'

  },
  h1: {
    fontWeight: 500,
    fontSize: "1.875rem",
    lineHeight: "1.5"
  },
  h2: {
    fontWeight: 500,
    fontSize: "1.5rem",
    lineHeight: "1.5"
  },
  h3: {
    fontWeight: 500,
    fontSize: "1.3125rem",
    lineHeight: "1.5"
  },
  h4: {
    fontWeight: 500,
    fontSize: "1.125rem",
    lineHeight: "1.5"
  },
  h5: {
    fontWeight: 500,
    fontSize: "1rem",
    lineHeight: "1.5"
  },
  h6: {
    fontWeight: 500,
    fontSize: "0.875rem",
    lineHeight: "1.5"
  },
  button: {
    textTransform: "none",
    fontWeight: "400"
  },
  subtitle1: {
    fontSize: "1rem",
    fontWeight: "400"
  },
  subtitle2: {
    fontSize: "0.875rem",
    fontWeight: "400"
  }
};
/* harmony default export */ const Typoraphy = (typography);
;// CONCATENATED MODULE: ./src/store/constants/index.js
// Layout and colors CONSTANTS
const LIGHT_THEME = 'LIGHT_THEME';
const DARK_THEME = 'DARK_THEME';
const THEME_COLOR = 'THEME_COLOR';
const constants_NAVBAR_BG = 'NAVBAR_BG';
const constants_SIDEBAR_BG = 'SIDEBAR_BG';
const DIRECTION = 'DIRECTION';
const BLUE_THEME = 'BLUE_THEME';
const GREEN_THEME = 'GREEN_THEME';
const RED_THEME = 'RED_THEME';
const BLACK_THEME = 'BLACK_THEME';
const PURPLE_THEME = 'PURPLE_THEME';
const INDIGO_THEME = 'INDIGO_THEME';
const ORANGE_THEME = 'ORANGE_THEME';
;// CONCATENATED MODULE: ./src/theme/Theme.js






 // Create a theme instance.

const baseTheme = {
  palette: {
    primary: {
      main: "#03c9d7",
      light: "#e5fafb",
      dark: "#05b2bd",
      contrastText: "#ffffff"
    },
    secondary: {
      main: "#fb9678",
      light: "#fcf1ed",
      dark: "#e67e5f",
      contrastText: "#ffffff"
    },
    success: {
      main: "#00c292",
      light: "#ebfaf2",
      dark: "#00964b",
      contrastText: "#ffffff"
    },
    danger: {
      main: "#e46a76",
      light: "#fdf3f5"
    },
    info: {
      main: "#0bb2fb",
      light: "#a7e3f4"
    },
    error: {
      main: "#e46a76",
      light: '#fdf3f5',
      dark: "#e45a68"
    },
    warning: {
      main: "#fec90f",
      light: '#fff4e5',
      dark: "#dcb014",
      contrastText: "#ffffff"
    },
    text: {
      secondary: "#777e89",
      danger: "#fc4b6c"
    },
    grey: {
      A100: "#ecf0f2",
      A200: "#99abb4",
      A400: "#767e89",
      A700: "#e6f4ff"
    },
    action: {
      disabledBackground: "rgba(73,82,88,0.12)",
      hoverOpacity: 0.02,
      hover: "rgba(0, 0, 0, 0.03)"
    },
    background: {
      default: "#fafbfb"
    }
  },
  mixins: {
    toolbar: {
      color: "#949db2",
      "@media(min-width:1280px)": {
        minHeight: "64px",
        padding: "0 30px"
      },
      "@media(max-width:1280px)": {
        minHeight: "64px"
      }
    }
  },
  components: ComponentOverRide,
  shadows: Shadows,
  typography: Typoraphy
};
const themesOptions = [{
  name: BLUE_THEME,
  palette: {
    primary: {
      main: "#1a97f5",
      light: "#e6f4ff",
      dark: "#1682d4"
    },
    secondary: {
      main: "#1e4db7",
      light: "#ddebff",
      dark: "#173f98"
    }
  }
}, {
  name: GREEN_THEME,
  palette: {
    primary: {
      main: "#00cec3",
      light: "#d7f8f6",
      dark: "#02b3a9",
      contrastText: "#ffffff"
    },
    secondary: {
      main: "#066a73"
    }
  }
}, {
  name: PURPLE_THEME,
  palette: {
    primary: {
      main: "#7352ff",
      light: "#e5e0fa",
      dark: "#5739d6"
    },
    secondary: {
      main: "#402e8d"
    }
  }
}, {
  name: INDIGO_THEME,
  palette: {
    primary: {
      main: "#1e4db7",
      light: "#e6f4ff",
      dark: "#0c399e"
    },
    secondary: {
      main: "#11397b"
    }
  }
}, {
  name: ORANGE_THEME,
  palette: {
    primary: {
      main: "#03c9d7",
      light: "#e5fafb",
      dark: "#05b2bd",
      contrastText: "#ffffff"
    },
    secondary: {
      main: "#fb9678",
      light: "#fcf1ed",
      dark: "#e67e5f",
      contrastText: "#ffffff"
    }
  }
}, {
  name: RED_THEME,
  palette: {
    primary: {
      main: "#ff5c8e",
      light: "#fce6ed",
      dark: "#d43653",
      contrastText: "#ffffff"
    },
    secondary: {
      main: "#5e244d"
    }
  }
}, {
  name: BLACK_THEME,
  palette: {
    primary: {
      main: "#1c2025"
    }
  }
}];
const BuildTheme = (config = {}) => {
  let themeOptions = themesOptions.find(theme => theme.name === config.theme);
  const customizer = (0,external_react_redux_.useSelector)(state => state.CustomizerReducer);
  const baseMode = {
    palette: {
      mode: customizer.activeMode,
      background: {
        default: customizer.activeMode === "dark" ? "#20232a" : "#fafbfb",
        dark: customizer.activeMode === "dark" ? "#1c2025" : "#ffffff",
        paper: customizer.activeMode === "dark" ? "#282C34" : "#ffffff"
      },
      text: {
        primary: customizer.activeMode === "dark" ? "#e6e5e8" : "rgba(0, 0, 0, 0.87)",
        secondary: customizer.activeMode === "dark" ? "#adb0bb" : "#777e89"
      }
    }
  };

  if (!themeOptions) {
    console.warn(new Error(`The theme ${config.theme} is not valid`));
    [themeOptions] = themesOptions;
  }

  const theme = (0,styles_.createTheme)(external_lodash_default().merge({}, baseTheme, baseMode, themeOptions, {
    direction: config.direction
  }));
  return theme;
};
;// CONCATENATED MODULE: ./src/theme/ThemeSettings.js




const ThemeSettings = () => {
  const customizer = (0,external_react_redux_.useSelector)(state => state.CustomizerReducer);
  const theme = BuildTheme({
    direction: customizer.activeDir,
    theme: customizer.activeTheme
  });
  (0,external_react_.useEffect)(() => {
    document.dir = customizer.activeDir;
  }, [customizer]);
  return theme;
};

/* harmony default export */ const theme_ThemeSettings = (ThemeSettings);
// EXTERNAL MODULE: ./src/createEmotionCache.js
var createEmotionCache = __webpack_require__(2803);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(5692);
// EXTERNAL MODULE: external "feather-icons-react"
var external_feather_icons_react_ = __webpack_require__(738);
var external_feather_icons_react_default = /*#__PURE__*/__webpack_require__.n(external_feather_icons_react_);
;// CONCATENATED MODULE: ./src/layouts/header/SearchDD.js







const SearchDD = () => {
  // drawer top
  const {
    0: showDrawer2,
    1: setShowDrawer2
  } = (0,external_react_.useState)(false);

  const handleDrawerClose2 = () => {
    setShowDrawer2(false);
  };

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
    children: [/*#__PURE__*/jsx_runtime_.jsx(material_.IconButton, {
      "aria-label": "show 4 new mails",
      color: "inherit",
      "aria-controls": "search-menu",
      "aria-haspopup": "true",
      onClick: () => setShowDrawer2(true),
      size: "large",
      children: /*#__PURE__*/jsx_runtime_.jsx((external_feather_icons_react_default()), {
        icon: "search",
        width: "20",
        height: "20"
      })
    }), /*#__PURE__*/jsx_runtime_.jsx(material_.Drawer, {
      anchor: "top",
      open: showDrawer2,
      onClose: () => setShowDrawer2(false),
      sx: {
        "& .MuiDrawer-paper": {
          padding: "15px 30px"
        }
      },
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Box, {
        display: "flex",
        alignItems: "center",
        children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Input, {
          placeholder: "Search here",
          "aria-label": "description",
          fullWidth: true
        }), /*#__PURE__*/jsx_runtime_.jsx(material_.Box, {
          sx: {
            ml: "auto"
          },
          children: /*#__PURE__*/jsx_runtime_.jsx(material_.IconButton, {
            color: "inherit",
            sx: {
              color: theme => theme.palette.grey.A200
            },
            onClick: handleDrawerClose2,
            children: /*#__PURE__*/jsx_runtime_.jsx((external_feather_icons_react_default()), {
              icon: "x-circle"
            })
          })
        })]
      })
    })]
  });
};

/* harmony default export */ const header_SearchDD = (SearchDD);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: ./assets/images/users/user2.jpg
var user2 = __webpack_require__(9220);
;// CONCATENATED MODULE: ./src/layouts/header/ProfileDD.js










const ProfileDD = ({
  data
}) => {
  const [anchorEl4, setAnchorEl4] = external_react_default().useState(null);

  const handleClick4 = event => {
    setAnchorEl4(event.currentTarget);
  };

  const handleClose4 = () => {
    setAnchorEl4(null);
  };

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
    children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Button, {
      "aria-label": "menu",
      color: "inherit",
      "aria-controls": "profile-menu",
      "aria-haspopup": "true",
      onClick: handleClick4,
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Box, {
        display: "flex",
        alignItems: "center",
        children: [/*#__PURE__*/jsx_runtime_.jsx(next_image["default"], {
          src: user2/* default */.Z,
          alt: user2/* default */.Z,
          width: "30",
          height: "30",
          className: "roundedCircle"
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Box, {
          sx: {
            display: {
              xs: "none",
              sm: "flex"
            },
            alignItems: "center"
          },
          children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
            color: "textSecondary",
            variant: "h5",
            fontWeight: "400",
            sx: {
              ml: 1
            },
            children: "Hi,"
          }), /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
            variant: "h5",
            fontWeight: "700",
            sx: {
              ml: 1
            },
            children: data.firstname
          }), /*#__PURE__*/jsx_runtime_.jsx((external_feather_icons_react_default()), {
            icon: "chevron-down",
            width: "20",
            height: "20"
          })]
        })]
      })
    }), /*#__PURE__*/jsx_runtime_.jsx(material_.Menu, {
      id: "profile-menu",
      anchorEl: anchorEl4,
      keepMounted: true,
      open: Boolean(anchorEl4),
      onClose: handleClose4,
      sx: {
        "& .MuiMenu-paper": {
          width: "385px",
          right: 0,
          top: "70px !important"
        },
        "& .MuiList-padding": {
          p: "30px"
        }
      },
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Box, {
        children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Box, {
          sx: {
            mb: 1
          },
          children: /*#__PURE__*/jsx_runtime_.jsx(material_.Box, {
            display: "flex",
            alignItems: "center",
            children: /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
              variant: "h4",
              fontWeight: "500",
              children: "User Profile"
            })
          })
        }), /*#__PURE__*/jsx_runtime_.jsx(material_.Box, {
          sx: {
            pb: 3,
            mt: 3
          },
          children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Box, {
            display: "flex",
            alignItems: "center",
            children: [/*#__PURE__*/jsx_runtime_.jsx(next_image["default"], {
              width: "90",
              height: "90",
              src: user2/* default */.Z,
              alt: user2/* default */.Z,
              className: "roundedCircle"
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Box, {
              sx: {
                ml: 2
              },
              children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Typography, {
                variant: "h4",
                sx: {
                  lineHeight: "1.235"
                },
                children: [data && data.firstname ? data.firstname : "", " ", data && data.lastname ? data.lastname : ""]
              }), /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
                color: "textSecondary",
                variant: "h6",
                fontWeight: "400",
                children: data && data.acctype ? data.acctype : 'Unknown Type'
              }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Box, {
                display: "flex",
                alignItems: "center",
                children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
                  color: "textSecondary",
                  display: "flex",
                  alignItems: "center",
                  sx: {
                    color: theme => theme.palette.grey.A200,
                    mr: 1
                  },
                  children: /*#__PURE__*/jsx_runtime_.jsx((external_feather_icons_react_default()), {
                    icon: "mail",
                    width: "18"
                  })
                }), /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
                  color: "textSecondary",
                  variant: "h6",
                  children: data && data.email ? data.email : "Email Unknown"
                })]
              })]
            })]
          })
        }), /*#__PURE__*/jsx_runtime_.jsx(material_.Divider, {
          style: {
            marginTop: 0,
            marginBottom: 0
          }
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Box, {
          children: [/*#__PURE__*/jsx_runtime_.jsx(material_.MenuItem, {
            sx: {
              pt: 3,
              pb: 3
            },
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Box, {
              display: "flex",
              alignItems: "center",
              children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Button, {
                sx: {
                  backgroundColor: theme => theme.palette.primary.light,
                  color: theme => theme.palette.primary.main,
                  boxShadow: "none",
                  minWidth: "50px",
                  width: "45px",
                  height: "40px",
                  borderRadius: "10px"
                },
                children: /*#__PURE__*/jsx_runtime_.jsx((external_feather_icons_react_default()), {
                  icon: "dollar-sign",
                  width: "18",
                  height: "18"
                })
              }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Box, {
                sx: {
                  ml: 2
                },
                children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
                  variant: "h5",
                  sx: {
                    lineHeight: "1.235"
                  },
                  children: "My Profile"
                }), /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
                  color: "textSecondary",
                  variant: "h6",
                  fontWeight: "400",
                  children: "Account Settings"
                })]
              })]
            })
          }), /*#__PURE__*/jsx_runtime_.jsx(material_.Divider, {
            style: {
              marginTop: 0,
              marginBottom: 0
            }
          }), /*#__PURE__*/jsx_runtime_.jsx(material_.MenuItem, {
            sx: {
              pt: 3,
              pb: 3
            },
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Box, {
              display: "flex",
              alignItems: "center",
              children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Button, {
                sx: {
                  backgroundColor: theme => theme.palette.error.light,
                  color: theme => theme.palette.error.main,
                  boxShadow: "none",
                  minWidth: "50px",
                  width: "45px",
                  height: "40px",
                  borderRadius: "10px"
                },
                children: /*#__PURE__*/jsx_runtime_.jsx((external_feather_icons_react_default()), {
                  icon: "credit-card",
                  width: "18",
                  height: "18"
                })
              }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Box, {
                sx: {
                  ml: 2
                },
                children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
                  variant: "h5",
                  sx: {
                    lineHeight: "1.235"
                  },
                  children: "My Referral Code"
                }), /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
                  color: "textSecondary",
                  variant: "h6",
                  fontWeight: "400",
                  children: data && data.referral_code ? data.referral_code : ""
                })]
              })]
            })
          })]
        }), /*#__PURE__*/jsx_runtime_.jsx(next_link["default"], {
          href: "/authentication/login",
          children: /*#__PURE__*/jsx_runtime_.jsx(material_.Button, {
            sx: {
              mt: 2,
              display: "block",
              width: "100%"
            },
            variant: "contained",
            color: "primary",
            children: "Logout"
          })
        })]
      })
    })]
  });
};

/* harmony default export */ const header_ProfileDD = (ProfileDD);
// EXTERNAL MODULE: ./assets/images/users/1.jpg
var _1 = __webpack_require__(7574);
// EXTERNAL MODULE: ./assets/images/users/2.jpg
var _2 = __webpack_require__(791);
// EXTERNAL MODULE: ./assets/images/users/3.jpg
var _3 = __webpack_require__(6430);
// EXTERNAL MODULE: ./assets/images/users/4.jpg
var _4 = __webpack_require__(7326);
;// CONCATENATED MODULE: ./assets/images/products/s1.jpg
/* harmony default export */ const s1 = ({"src":"/_next/static/media/s1.e08be6fb.jpg","height":492,"width":524,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAgACAMBIgACEQEDEQH/xAAoAAEBAAAAAAAAAAAAAAAAAAAABgEBAQAAAAAAAAAAAAAAAAAAAgX/2gAMAwEAAhADEAAAAK0Cl//EABoQAAEFAQAAAAAAAAAAAAAAAAEAAgMEEWH/2gAIAQEAAT8AqBjrVmEaQyKI8BO6v//EABkRAAEFAAAAAAAAAAAAAAAAAAABAhEhcf/aAAgBAgEBPwBtzqn/xAAXEQEBAQEAAAAAAAAAAAAAAAABAgAh/9oACAEDAQE/AKpF7v/Z"});
;// CONCATENATED MODULE: ./assets/images/products/s2.jpg
/* harmony default export */ const s2 = ({"src":"/_next/static/media/s2.50f2e297.jpg","height":492,"width":524,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAgACAMBIgACEQEDEQH/xAAoAAEBAAAAAAAAAAAAAAAAAAAABgEBAQAAAAAAAAAAAAAAAAAABQb/2gAMAwEAAhADEAAAAKUQyn//xAAcEAABAwUAAAAAAAAAAAAAAAABAAMEAgUSFDL/2gAIAQEAAT8AekzxcqWw0NTDpf/EABgRAQADAQAAAAAAAAAAAAAAAAEAAiED/9oACAECAQE/AOl1TAyf/8QAGBEAAgMAAAAAAAAAAAAAAAAAAAEhMUH/2gAIAQMBAT8AeQqP/9k="});
;// CONCATENATED MODULE: ./assets/images/products/s3.jpg
/* harmony default export */ const s3 = ({"src":"/_next/static/media/s3.60ec464b.jpg","height":492,"width":524,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAgACAMBIgACEQEDEQH/xAAoAAEBAAAAAAAAAAAAAAAAAAAABgEBAQAAAAAAAAAAAAAAAAAABAX/2gAMAwEAAhADEAAAALwNk//EABgQAAIDAAAAAAAAAAAAAAAAAAACERJh/9oACAEBAAE/AFV75J//xAAYEQACAwAAAAAAAAAAAAAAAAAAEQEhMf/aAAgBAgEBPwBJ3On/xAAZEQEAAgMAAAAAAAAAAAAAAAABEiEAAhH/2gAIAQMBAT8AdpRoOAVn/9k="});
;// CONCATENATED MODULE: ./src/layouts/header/data.js






 //
// Notifications dropdown
//

const notifications = [{
  avatar: _1/* default */.Z,
  title: "Roman Joined the Team!",
  subtitle: "Congratulate him"
}, {
  avatar: _2/* default */.Z,
  title: "New message received",
  subtitle: "Salma sent you new message"
}, {
  avatar: _3/* default */.Z,
  title: "New Payment received",
  subtitle: "Check your earnings"
}, {
  avatar: _4/* default */.Z,
  title: "Jolly completed tasks",
  subtitle: "Assign her new tasks"
}]; //
// Messages dropdown
//

const messages = [{
  avatar: _1/* default */.Z,
  title: "Roman Joined the Team!",
  subtitle: "Congratulate him",
  time: "9:08 AM",
  status: "success"
}, {
  avatar: _2/* default */.Z,
  title: "New message received",
  subtitle: "Salma sent you new message",
  time: "11:56 AM",
  status: "warning"
}, {
  avatar: _3/* default */.Z,
  title: "New Payment received",
  subtitle: "Check your earnings",
  time: "4:39 AM",
  status: "success"
}, {
  avatar: _4/* default */.Z,
  title: "Jolly completed tasks",
  subtitle: "Assign her new tasks",
  time: "1:12 AM",
  status: "danger"
}]; //
// Ecommerce dropdown
//

const products = [{
  imgsrc: s1,
  name: "butterscotch ice-cream",
  subtext: "Milk product",
  price: "250"
}, {
  imgsrc: s2,
  name: "Supreme fresh tomato",
  subtext: "Vegetable Item",
  price: "450"
}, {
  imgsrc: s3,
  name: "Red color candy",
  subtext: "Food Item",
  price: "190"
}];

;// CONCATENATED MODULE: ./src/layouts/header/CartDropdown.js









function SimpleDialog(props) {
  const {
    onClose,
    open
  } = props;

  const handleClose = () => {
    onClose(true);
  };

  return /*#__PURE__*/_jsx(Dialog, {
    "aria-labelledby": "simple-dialog-title",
    open: open,
    fullWidth: true,
    children: /*#__PURE__*/_jsx(DialogTitle, {
      id: "simple-dialog-title",
      children: /*#__PURE__*/_jsxs(Box, {
        sx: {
          display: {
            xs: "block",
            sm: "flex",
            lg: "flex"
          },
          alignItems: "center",
          color: "success.main"
        },
        children: [/*#__PURE__*/_jsx(FeatherIcon, {
          icon: "shopping-cart",
          width: "20",
          height: "20"
        }), /*#__PURE__*/_jsx(Typography, {
          variant: "h4",
          sx: {
            ml: 2
          },
          children: "Order Successfully Done"
        }), /*#__PURE__*/_jsx(Box, {
          sx: {
            ml: "auto"
          },
          children: /*#__PURE__*/_jsx(Button, {
            color: "error",
            onClick: handleClose,
            autoFocus: true,
            children: "Close"
          })
        })]
      })
    })
  });
}

const CartDropdown = () => {
  // increment & decrement
  const {
    0: count,
    1: setCount
  } = useState(0);

  const Increase = () => {
    setCount(count + 1);
  };

  const Decrease = () => {
    setCount(count - 1);
  }; // dialog


  const [open, setOpen] = React.useState(false);

  const handleClickOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  }; // drawer


  const {
    0: showDrawer,
    1: setShowDrawer
  } = useState(false);

  const handleDrawerClose = () => {
    setShowDrawer(false);
  };

  return /*#__PURE__*/_jsxs(_Fragment, {
    children: [/*#__PURE__*/_jsx(IconButton, {
      size: "large",
      color: "inherit",
      onClick: () => setShowDrawer(true),
      children: /*#__PURE__*/_jsx(FeatherIcon, {
        icon: "shopping-cart",
        width: "20",
        height: "20"
      })
    }), /*#__PURE__*/_jsxs(Drawer, {
      anchor: "right",
      open: showDrawer,
      onClose: () => setShowDrawer(false),
      sx: {
        "& .MuiDrawer-paper": {
          width: {
            xs: "100%",
            sm: "395px"
          },
          padding: "30px"
        }
      },
      children: [/*#__PURE__*/_jsxs(Box, {
        display: "flex",
        alignItems: "center",
        children: [/*#__PURE__*/_jsx(Typography, {
          variant: "h4",
          fontWeight: "500",
          children: "Shopping Cart"
        }), /*#__PURE__*/_jsx(Box, {
          sx: {
            ml: "auto"
          },
          children: /*#__PURE__*/_jsx(IconButton, {
            color: "inherit",
            sx: {
              color: theme => theme.palette.grey.A200
            },
            onClick: handleDrawerClose,
            children: /*#__PURE__*/_jsx(FeatherIcon, {
              icon: "x-circle"
            })
          })
        })]
      }), /*#__PURE__*/_jsxs(Box, {
        children: [/*#__PURE__*/_jsx(Box, {
          children: data.products.map(product => /*#__PURE__*/_jsxs(Box, {
            children: [/*#__PURE__*/_jsxs(Box, {
              display: "flex",
              alignItems: "center",
              sx: {
                pb: 4,
                pt: 3
              },
              children: [/*#__PURE__*/_jsx(Image, {
                src: product.imgsrc,
                alt: product.imgsrc,
                height: "70px",
                width: "90px"
              }), /*#__PURE__*/_jsxs(Box, {
                sx: {
                  ml: 2
                },
                children: [/*#__PURE__*/_jsx(Typography, {
                  variant: "h5",
                  children: product.name
                }), /*#__PURE__*/_jsx(Typography, {
                  color: "textSecondary",
                  variant: "h6",
                  children: product.subtext
                }), /*#__PURE__*/_jsxs(Box, {
                  display: "flex",
                  alignItems: "center",
                  sx: {
                    mt: 1
                  },
                  children: [/*#__PURE__*/_jsxs(Typography, {
                    variant: "h5",
                    children: ["$", product.price]
                  }), /*#__PURE__*/_jsx(Box, {
                    sx: {
                      ml: 1
                    },
                    children: /*#__PURE__*/_jsxs(ButtonGroup, {
                      size: "small",
                      color: "success",
                      "aria-label": "small button group",
                      children: [/*#__PURE__*/_jsx(Button, {
                        onClick: Decrease,
                        sx: {
                          width: "35px",
                          height: "35px",
                          padding: "5px"
                        },
                        children: /*#__PURE__*/_jsx(FeatherIcon, {
                          icon: "minus",
                          width: "18",
                          height: "18"
                        })
                      }), /*#__PURE__*/_jsx(Button, {
                        sx: {
                          width: "35px",
                          height: "35px",
                          padding: "5px"
                        },
                        children: count
                      }), /*#__PURE__*/_jsx(Button, {
                        onClick: Increase,
                        sx: {
                          width: "35px",
                          height: "35px",
                          padding: "5px"
                        },
                        children: /*#__PURE__*/_jsx(FeatherIcon, {
                          icon: "plus",
                          width: "18",
                          height: "18"
                        })
                      })]
                    })
                  })]
                })]
              })]
            }), /*#__PURE__*/_jsx(Divider, {})]
          }, product.name))
        }), /*#__PURE__*/_jsxs(Box, {
          display: "flex",
          alignItems: "center",
          sx: {
            mt: 2
          },
          children: [/*#__PURE__*/_jsx(Typography, {
            color: "textSecondary",
            variant: "h6",
            fontWeight: "400",
            children: "Sub Total"
          }), /*#__PURE__*/_jsx(Box, {
            sx: {
              ml: "auto"
            },
            children: /*#__PURE__*/_jsx(Typography, {
              variant: "h6",
              children: "$890"
            })
          })]
        }), /*#__PURE__*/_jsxs(Box, {
          display: "flex",
          alignItems: "center",
          sx: {
            mt: 2
          },
          children: [/*#__PURE__*/_jsx(Typography, {
            color: "textSecondary",
            variant: "h6",
            fontWeight: "400",
            children: "Total"
          }), /*#__PURE__*/_jsx(Box, {
            sx: {
              ml: "auto"
            },
            children: /*#__PURE__*/_jsx(Typography, {
              variant: "h6",
              children: "$890"
            })
          })]
        }), /*#__PURE__*/_jsx(Button, {
          sx: {
            mt: 2,
            display: "block",
            width: "100%"
          },
          variant: "contained",
          color: "primary",
          onClick: handleClickOpen,
          children: "Place order"
        }), /*#__PURE__*/_jsx(SimpleDialog, {
          open: open,
          onClose: handleClose
        })]
      })]
    })]
  });
};

/* harmony default export */ const header_CartDropdown = ((/* unused pure expression or super */ null && (CartDropdown)));
;// CONCATENATED MODULE: ./src/layouts/header/MessageDropdown.js









const MessageDropdown = () => {
  const [anchorEl2, setAnchorEl2] = React.useState(null);

  const handleClick2 = event => {
    setAnchorEl2(event.currentTarget);
  };

  const handleClose2 = () => {
    setAnchorEl2(null);
  };

  return /*#__PURE__*/_jsxs(_Fragment, {
    children: [/*#__PURE__*/_jsx(IconButton, {
      size: "large",
      "aria-label": "show 11 new notifications",
      color: "inherit",
      "aria-controls": "msgs-menu",
      "aria-haspopup": "true",
      onClick: handleClick2,
      children: /*#__PURE__*/_jsx(Badge, {
        variant: "dot",
        color: "primary",
        children: /*#__PURE__*/_jsx(FeatherIcon, {
          icon: "message-square",
          width: "20",
          height: "20"
        })
      })
    }), /*#__PURE__*/_jsxs(Menu, {
      id: "msgs-menu",
      anchorEl: anchorEl2,
      keepMounted: true,
      open: Boolean(anchorEl2),
      onClose: handleClose2,
      anchorOrigin: {
        horizontal: "right",
        vertical: "bottom"
      },
      transformOrigin: {
        horizontal: "right",
        vertical: "top"
      },
      sx: {
        "& .MuiMenu-paper": {
          width: "385px",
          right: 0,
          top: "70px !important"
        },
        "& .MuiList-padding": {
          p: "30px"
        }
      },
      children: [/*#__PURE__*/_jsx(Box, {
        sx: {
          mb: 1
        },
        children: /*#__PURE__*/_jsxs(Box, {
          display: "flex",
          alignItems: "center",
          children: [/*#__PURE__*/_jsx(Typography, {
            variant: "h4",
            fontWeight: "500",
            children: "Messages"
          }), /*#__PURE__*/_jsx(Box, {
            sx: {
              ml: 2
            },
            children: /*#__PURE__*/_jsx(Chip, {
              size: "small",
              label: "5 new",
              sx: {
                borderRadius: "6px",
                pl: "5px",
                pr: "5px",
                backgroundColor: theme => theme.palette.secondary.main,
                color: "#fff"
              }
            })
          })]
        })
      }), /*#__PURE__*/_jsx(Box, {
        children: data.messages.map(message => /*#__PURE__*/_jsxs(Box, {
          children: [/*#__PURE__*/_jsx(MenuItem, {
            sx: {
              pt: 2,
              pb: 2,
              borderRadius: "0px"
            },
            children: /*#__PURE__*/_jsxs(Box, {
              display: "flex",
              alignItems: "center",
              children: [/*#__PURE__*/_jsx(Badge, {
                variant: "dot",
                color: message.status,
                children: /*#__PURE__*/_jsx(Image, {
                  src: message.avatar,
                  alt: message.avatar,
                  width: "45px",
                  height: "45px",
                  className: "roundedCircle"
                })
              }), /*#__PURE__*/_jsxs(Box, {
                sx: {
                  ml: 2
                },
                children: [/*#__PURE__*/_jsx(Typography, {
                  variant: "h5",
                  noWrap: true,
                  sx: {
                    width: "240px"
                  },
                  children: message.title
                }), /*#__PURE__*/_jsx(Typography, {
                  color: "textSecondary",
                  variant: "h6",
                  fontWeight: "400",
                  sx: {
                    width: "240px"
                  },
                  noWrap: true,
                  children: message.subtitle
                }), /*#__PURE__*/_jsx(Typography, {
                  color: "textSecondary",
                  variant: "body2",
                  children: message.time
                })]
              })]
            })
          }), /*#__PURE__*/_jsx(Divider, {
            style: {
              marginTop: 0,
              marginBottom: 0
            }
          })]
        }, message.title))
      }), /*#__PURE__*/_jsx(Button, {
        sx: {
          mt: 2,
          display: "block",
          width: "100%"
        },
        variant: "contained",
        color: "primary",
        onClick: handleClose2,
        children: /*#__PURE__*/_jsx(Link, {
          to: "/email",
          style: {
            color: "#fff",
            width: "100%",
            display: "block",
            textDecoration: "none"
          },
          children: "See all messages"
        })
      })]
    })]
  });
};

/* harmony default export */ const header_MessageDropdown = ((/* unused pure expression or super */ null && (MessageDropdown)));
;// CONCATENATED MODULE: ./src/layouts/header/NotificationDropdown.js









const NotificationDropdown = () => {
  const [anchorEl, setAnchorEl] = external_react_default().useState(null);

  const handleClick = event => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
    children: [/*#__PURE__*/jsx_runtime_.jsx(material_.IconButton, {
      size: "large",
      "aria-label": "menu",
      color: "inherit",
      "aria-controls": "notification-menu",
      "aria-haspopup": "true",
      onClick: handleClick,
      children: /*#__PURE__*/jsx_runtime_.jsx(material_.Badge, {
        variant: "dot",
        color: "secondary",
        children: /*#__PURE__*/jsx_runtime_.jsx((external_feather_icons_react_default()), {
          icon: "bell",
          width: "20",
          height: "20"
        })
      })
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Menu, {
      id: "notification-menu",
      anchorEl: anchorEl,
      keepMounted: true,
      open: Boolean(anchorEl),
      onClose: handleClose,
      anchorOrigin: {
        horizontal: "right",
        vertical: "bottom"
      },
      transformOrigin: {
        horizontal: "right",
        vertical: "top"
      },
      sx: {
        "& .MuiMenu-paper": {
          width: "385px",
          right: 0,
          top: "70px !important"
        },
        "& .MuiList-padding": {
          p: "30px"
        }
      },
      children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Box, {
        sx: {
          mb: 1
        },
        children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Box, {
          display: "flex",
          alignItems: "center",
          children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
            variant: "h4",
            fontWeight: "500",
            children: "Notifications"
          }), /*#__PURE__*/jsx_runtime_.jsx(material_.Box, {
            sx: {
              ml: 2
            },
            children: /*#__PURE__*/jsx_runtime_.jsx(material_.Chip, {
              size: "small",
              label: "5 new",
              sx: {
                borderRadius: "6px",
                pl: "5px",
                pr: "5px",
                backgroundColor: theme => theme.palette.warning.main,
                color: "#fff"
              }
            })
          })]
        })
      }), /*#__PURE__*/jsx_runtime_.jsx(material_.Box, {
        children: notifications.map(notification => /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Box, {
          children: [/*#__PURE__*/jsx_runtime_.jsx(material_.MenuItem, {
            sx: {
              pt: 2,
              pb: 2,
              borderRadius: "0px"
            },
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Box, {
              display: "flex",
              alignItems: "center",
              children: [/*#__PURE__*/jsx_runtime_.jsx(next_image["default"], {
                src: notification.avatar,
                alt: notification.avatar,
                width: "45px",
                height: "45px",
                className: "roundedCircle"
              }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Box, {
                sx: {
                  ml: 2
                },
                children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
                  variant: "h5",
                  noWrap: true,
                  sx: {
                    width: "240px"
                  },
                  children: notification.title
                }), /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
                  color: "textSecondary",
                  variant: "h6",
                  noWrap: true,
                  fontWeight: "400",
                  sx: {
                    width: "240px"
                  },
                  children: notification.subtitle
                })]
              })]
            })
          }), /*#__PURE__*/jsx_runtime_.jsx(material_.Divider, {
            style: {
              marginTop: 0,
              marginBottom: 0
            }
          })]
        }, notification.title))
      }), /*#__PURE__*/jsx_runtime_.jsx(material_.Button, {
        sx: {
          mt: 2,
          display: "block",
          width: "100%"
        },
        variant: "contained",
        color: "primary",
        onClick: handleClose,
        children: /*#__PURE__*/jsx_runtime_.jsx(material_.Link, {
          to: "/email",
          style: {
            color: "#fff",
            width: "100%",
            display: "block",
            textDecoration: "none"
          },
          children: "See all notifications"
        })
      })]
    })]
  });
};

/* harmony default export */ const header_NotificationDropdown = (NotificationDropdown);
;// CONCATENATED MODULE: ./src/layouts/header/Header.js



// Dropdown Component








const Header = ({
  sx,
  customClass,
  toggleSidebar,
  toggleMobileSidebar,
  position
}) => {
  const {
    0: userData,
    1: setUserData
  } = (0,external_react_.useState)("");
  (0,external_react_.useEffect)(() => {
    const currentUser = JSON.parse(localStorage.getItem("userData"));
    setUserData(currentUser);
  }, []);
  return /*#__PURE__*/jsx_runtime_.jsx(material_.AppBar, {
    sx: sx,
    position: position,
    elevation: 0,
    className: customClass,
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Toolbar, {
      children: [/*#__PURE__*/jsx_runtime_.jsx(material_.IconButton, {
        edge: "start",
        color: "inherit",
        "aria-label": "menu",
        onClick: toggleSidebar,
        size: "large",
        sx: {
          display: {
            lg: "flex",
            xs: "none"
          }
        },
        children: /*#__PURE__*/jsx_runtime_.jsx((external_feather_icons_react_default()), {
          icon: "menu"
        })
      }), /*#__PURE__*/jsx_runtime_.jsx(material_.IconButton, {
        size: "large",
        color: "inherit",
        "aria-label": "menu",
        onClick: toggleMobileSidebar,
        sx: {
          display: {
            lg: "none",
            xs: "flex"
          }
        },
        children: /*#__PURE__*/jsx_runtime_.jsx((external_feather_icons_react_default()), {
          icon: "menu",
          width: "20",
          height: "20"
        })
      }), /*#__PURE__*/jsx_runtime_.jsx(header_SearchDD, {}), /*#__PURE__*/jsx_runtime_.jsx(material_.Box, {
        flexGrow: 1
      }), /*#__PURE__*/jsx_runtime_.jsx(header_NotificationDropdown, {}), /*#__PURE__*/jsx_runtime_.jsx(material_.Box, {
        sx: {
          width: "1px",
          backgroundColor: "rgba(0,0,0,0.1)",
          height: "25px",
          ml: 1,
          mr: 1
        }
      }), /*#__PURE__*/jsx_runtime_.jsx(header_ProfileDD, {
        data: userData
      })]
    })
  });
};

/* harmony default export */ const header_Header = (Header);
// EXTERNAL MODULE: ./src/layouts/logo/LogoIcon.js + 3 modules
var LogoIcon = __webpack_require__(4389);
;// CONCATENATED MODULE: ./src/layouts/sidebar/MenuItems.js
const Menuitems = [{
  navlabel: true,
  subheader: "DASHBOARDS",
  icon: "mdi mdi-dots-horizontal",
  href: "Dashboard"
}, {
  title: "Dashboard",
  icon: "pie-chart",
  href: "/dashboards/dashboard1"
}, {
  navlabel: true,
  subheader: "LINKS",
  icon: "mdi mdi-dots-horizontal",
  href: "Apps"
}, {
  title: "My Wallet",
  icon: "message-square",
  href: "/dashboards/wallet"
}, {
  title: "Bonus",
  icon: "dollar-sign",
  href: "/dashboards/bonus"
}, {
  title: "Buy Airtime",
  icon: "refresh-ccw",
  href: "/dashboards/purchase/airtime"
}, {
  title: "Buy Data",
  icon: "refresh-cw",
  href: "/dashboards/purchase/data"
}, // {
//   title: "Services",
//   icon: "settings",
//   href: "#",
// },
{
  title: "Services",
  icon: "clipboard",
  href: "/dashboards/services"
}, {
  title: "My Profile",
  icon: "user",
  href: "/dashboards/profile"
}, {
  navlabel: true,
  subheader: "AUTHENTICATION",
  icon: "mdi mdi-dots-horizontal",
  href: "Authentication"
}, {
  title: "Log Out",
  icon: "log-out",
  href: "/authentication/login"
}];
/* harmony default export */ const MenuItems = (Menuitems);
;// CONCATENATED MODULE: external "simplebar-react"
const external_simplebar_react_namespaceObject = require("simplebar-react");
var external_simplebar_react_default = /*#__PURE__*/__webpack_require__.n(external_simplebar_react_namespaceObject);
;// CONCATENATED MODULE: ./src/layouts/sidebar/Sidebar.js
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }






 // import Buynow from "./Buynow";






const Sidebar = ({
  isMobileSidebarOpen,
  onSidebarClose,
  isSidebarOpen,
  isUrl
}) => {
  const [open, setOpen] = external_react_default().useState(true);
  const router = (0,router_.useRouter)();
  const pathDirect = router.pathname;
  const location = router.pathname;
  const pathWithoutLastPart = router.pathname.slice(0, router.pathname.lastIndexOf("/"));
  const lgUp = (0,material_.useMediaQuery)(theme => theme.breakpoints.up("lg"));

  const handleClick = index => {
    if (open === index) {
      setOpen(prevopen => !prevopen);
      console.log(location);
    } else {
      setOpen(index);
    }
  };

  const SidebarContent = /*#__PURE__*/jsx_runtime_.jsx((external_simplebar_react_default()), {
    style: {
      height: "100%"
    },
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Box, {
      p: 2,
      height: "100%",
      children: [/*#__PURE__*/jsx_runtime_.jsx(LogoIcon/* default */.Z, {}), /*#__PURE__*/jsx_runtime_.jsx(material_.Box, {
        mt: 2,
        children: /*#__PURE__*/jsx_runtime_.jsx(material_.List, {
          children: MenuItems.map((item, index) => {
            // {/********SubHeader**********/}
            if (item.subheader) {
              return /*#__PURE__*/jsx_runtime_.jsx("li", {
                children: /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
                  variant: "subtitle2",
                  fontWeight: "500",
                  sx: {
                    my: 2,
                    mt: 4,
                    opacity: "0.4"
                  },
                  children: item.subheader
                })
              }, item.subheader); // {/********If Sub Menu**********/}

              /* eslint no-else-return: "off" */
            } else if (item.children) {
              return /*#__PURE__*/(0,jsx_runtime_.jsxs)((external_react_default()).Fragment, {
                children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.ListItem, {
                  button: true,
                  component: "li",
                  onClick: () => handleClick(index),
                  selected: pathWithoutLastPart === item.href,
                  sx: _objectSpread({
                    mb: 1
                  }, pathWithoutLastPart === item.href && {
                    color: "white",
                    backgroundColor: theme => `${theme.palette.primary.main}!important`
                  }),
                  children: [/*#__PURE__*/jsx_runtime_.jsx(material_.ListItemIcon, {
                    sx: _objectSpread({}, pathWithoutLastPart === item.href && {
                      color: "white"
                    }),
                    children: /*#__PURE__*/jsx_runtime_.jsx((external_feather_icons_react_default()), {
                      icon: item.icon,
                      width: "20",
                      height: "20"
                    })
                  }), /*#__PURE__*/jsx_runtime_.jsx(material_.ListItemText, {
                    children: item.title
                  }), index === open || pathWithoutLastPart === item.href ? /*#__PURE__*/jsx_runtime_.jsx((external_feather_icons_react_default()), {
                    icon: "chevron-down",
                    size: "16"
                  }) : /*#__PURE__*/jsx_runtime_.jsx((external_feather_icons_react_default()), {
                    icon: "chevron-right",
                    size: "16"
                  })]
                }), /*#__PURE__*/jsx_runtime_.jsx(material_.Collapse, {
                  in: index === open || pathWithoutLastPart === item.href,
                  timeout: "auto",
                  unmountOnExit: true,
                  children: /*#__PURE__*/jsx_runtime_.jsx(material_.List, {
                    component: "li",
                    disablePadding: true,
                    children: item.children.map(child => {
                      return /*#__PURE__*/jsx_runtime_.jsx(next_link["default"], {
                        href: child.href,
                        onClick: onSidebarClose,
                        children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.ListItem, {
                          button: true,
                          selected: pathDirect === child.href,
                          sx: _objectSpread({
                            mb: 1
                          }, pathDirect === child.href && {
                            color: "primary.main",
                            backgroundColor: "transparent!important"
                          }),
                          children: [/*#__PURE__*/jsx_runtime_.jsx(material_.ListItemIcon, {
                            sx: _objectSpread({
                              svg: {
                                width: "14px",
                                marginLeft: "3px"
                              }
                            }, pathDirect === child.href && {
                              color: "primary.main"
                            }),
                            children: /*#__PURE__*/jsx_runtime_.jsx((external_feather_icons_react_default()), {
                              icon: child.icon,
                              width: "20",
                              height: "20"
                            })
                          }), /*#__PURE__*/jsx_runtime_.jsx(material_.ListItemText, {
                            children: child.title
                          })]
                        })
                      }, child.title);
                    })
                  })
                })]
              }, item.title); // {/********If Sub No Menu**********/}
            } else {
              return /*#__PURE__*/jsx_runtime_.jsx(material_.List, {
                component: "li",
                disablePadding: true,
                children: /*#__PURE__*/jsx_runtime_.jsx(next_link["default"], {
                  href: item.href,
                  children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.ListItem, {
                    onClick: () => handleClick(index),
                    button: true,
                    selected: pathDirect === item.href,
                    sx: _objectSpread({
                      mb: 1
                    }, pathDirect === item.href && {
                      color: "white",
                      backgroundColor: theme => `${theme.palette.primary.main}!important`
                    }),
                    children: [/*#__PURE__*/jsx_runtime_.jsx(material_.ListItemIcon, {
                      sx: _objectSpread({}, pathDirect === item.href && {
                        color: "white"
                      }),
                      children: /*#__PURE__*/jsx_runtime_.jsx((external_feather_icons_react_default()), {
                        icon: item.icon,
                        width: "20",
                        height: "20"
                      })
                    }), /*#__PURE__*/jsx_runtime_.jsx(material_.ListItemText, {
                      onClick: onSidebarClose,
                      children: item.title
                    })]
                  })
                })
              }, item.title);
            }
          })
        })
      })]
    })
  });

  if (lgUp) {
    return /*#__PURE__*/jsx_runtime_.jsx(material_.Drawer, {
      anchor: "left",
      open: isSidebarOpen,
      variant: "persistent",
      PaperProps: {
        sx: {
          width: "265px",
          border: "0 !important",
          boxShadow: "0px 7px 30px 0px rgb(113 122 131 / 11%)"
        }
      },
      children: SidebarContent
    });
  }

  return /*#__PURE__*/jsx_runtime_.jsx(material_.Drawer, {
    anchor: "left",
    open: isMobileSidebarOpen,
    onClose: onSidebarClose,
    PaperProps: {
      sx: {
        width: "265px",
        border: "0 !important"
      }
    },
    variant: "temporary",
    children: SidebarContent
  });
};

/* harmony default export */ const sidebar_Sidebar = (Sidebar);
;// CONCATENATED MODULE: ./src/layouts/footer/Footer.js






const Footer = () => {
  return /*#__PURE__*/jsx_runtime_.jsx(material_.Box, {
    sx: {
      p: 3,
      textAlign: "center"
    },
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Typography, {
      children: ["\xA9 2022 All rights reserved by", " ", /*#__PURE__*/jsx_runtime_.jsx(next_link["default"], {
        href: "#",
        children: /*#__PURE__*/jsx_runtime_.jsx("a", {
          children: "rightNet"
        })
      }), " "]
    })
  });
};

/* harmony default export */ const footer_Footer = (Footer);
;// CONCATENATED MODULE: ./src/store/customizer/Action.js

const setTheme = payload => ({
  type: THEME_COLOR,
  payload
});
const setDarkMode = payload => ({
  type: DARK_THEME,
  payload
});
const setNavbarBg = payload => ({
  type: NAVBAR_BG,
  payload
});
const setSidebarBg = payload => ({
  type: SIDEBAR_BG,
  payload
});
const setDir = payload => ({
  type: DIRECTION,
  payload
});
// EXTERNAL MODULE: ./src/components/forms/custom-elements/CustomRadio.js
var CustomRadio = __webpack_require__(2373);
;// CONCATENATED MODULE: ./src/layouts/customizer/Customizer.js








const SidebarWidth = "320px";

const Customizer = () => {
  const {
    0: showDrawer,
    1: setShowDrawer
  } = (0,external_react_.useState)(false);
  const customizer = (0,external_react_redux_.useSelector)(state => state.CustomizerReducer);
  const dispatch = (0,external_react_redux_.useDispatch)();
  const thColors = [{
    id: 1,
    bgColor: "#1a9bfc",
    disp: "BLUE_THEME"
  }, {
    id: 2,
    bgColor: "#00cec3",
    disp: "GREEN_THEME"
  }, {
    id: 3,
    bgColor: "#7352ff",
    disp: "PURPLE_THEME"
  }, {
    id: 4,
    bgColor: "#ff5c8e",
    disp: "RED_THEME"
  }, {
    id: 5,
    bgColor: "#1e4db7",
    disp: "INDIGO_THEME"
  }, {
    id: 6,
    bgColor: "#fb9678",
    disp: "ORANGE_THEME"
  }];
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Tooltip, {
      title: "Settings",
      children: /*#__PURE__*/jsx_runtime_.jsx(material_.Fab, {
        color: "primary",
        "aria-label": "settings",
        sx: {
          position: "fixed",
          right: "15px",
          bottom: "15px"
        },
        onClick: () => setShowDrawer(true),
        children: /*#__PURE__*/jsx_runtime_.jsx((external_feather_icons_react_default()), {
          icon: "settings"
        })
      })
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Drawer, {
      anchor: "right",
      open: showDrawer,
      onClose: () => setShowDrawer(false),
      PaperProps: {
        sx: {
          width: SidebarWidth
        }
      },
      children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Box, {
        p: 2,
        children: /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
          variant: "h3",
          children: "Settings"
        })
      }), /*#__PURE__*/jsx_runtime_.jsx(material_.Divider, {}), /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Box, {
        p: 2,
        children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
          variant: "h4",
          gutterBottom: true,
          children: "Theme Option"
        }), /*#__PURE__*/jsx_runtime_.jsx(material_.FormControl, {
          component: "fieldset",
          children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.RadioGroup, {
            "aria-label": "theme",
            name: "theme",
            value: customizer.activeMode,
            onChange: event => dispatch(setDarkMode(event.target.value)),
            children: [/*#__PURE__*/jsx_runtime_.jsx(material_.FormControlLabel, {
              value: "light",
              control: /*#__PURE__*/jsx_runtime_.jsx(CustomRadio/* default */.Z, {}),
              label: "Light"
            }), /*#__PURE__*/jsx_runtime_.jsx(material_.FormControlLabel, {
              value: "dark",
              control: /*#__PURE__*/jsx_runtime_.jsx(CustomRadio/* default */.Z, {}),
              label: "Dark"
            })]
          })
        }), /*#__PURE__*/jsx_runtime_.jsx(material_.Box, {
          pt: 3
        }), /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
          variant: "h4",
          gutterBottom: true,
          children: "Theme Direction"
        }), /*#__PURE__*/jsx_runtime_.jsx(material_.FormControl, {
          component: "fieldset",
          children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.RadioGroup, {
            "aria-label": "themedir",
            name: "themedir",
            value: customizer.activeDir,
            onChange: event => dispatch(setDir(event.target.value)),
            children: [/*#__PURE__*/jsx_runtime_.jsx(material_.FormControlLabel, {
              value: "ltr",
              control: /*#__PURE__*/jsx_runtime_.jsx(CustomRadio/* default */.Z, {}),
              label: "LTR"
            }), /*#__PURE__*/jsx_runtime_.jsx(material_.FormControlLabel, {
              value: "rtl",
              control: /*#__PURE__*/jsx_runtime_.jsx(CustomRadio/* default */.Z, {}),
              label: "RTL"
            })]
          })
        }), /*#__PURE__*/jsx_runtime_.jsx(material_.Box, {
          pt: 3
        }), /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
          variant: "h4",
          gutterBottom: true,
          children: "Theme Colors"
        }), thColors.map(thcolor => /*#__PURE__*/jsx_runtime_.jsx(material_.Tooltip, {
          title: thcolor.disp,
          placement: "top",
          children: /*#__PURE__*/jsx_runtime_.jsx(material_.Fab, {
            color: "primary",
            style: {
              backgroundColor: thcolor.bgColor
            },
            sx: {
              marginRight: "3px"
            },
            size: "small",
            onClick: () => dispatch(setTheme(thcolor.disp)),
            "aria-label": thcolor.bgcolor,
            children: customizer.activeTheme === thcolor.disp ? /*#__PURE__*/jsx_runtime_.jsx((external_feather_icons_react_default()), {
              icon: "check",
              size: "16"
            }) : ""
          })
        }, thcolor.id)), /*#__PURE__*/jsx_runtime_.jsx(material_.Box, {
          pt: 3
        })]
      })]
    })]
  });
};

/* harmony default export */ const customizer_Customizer = (Customizer);
;// CONCATENATED MODULE: ./src/layouts/FullLayout.js









const MainWrapper = (0,material_.experimentalStyled)("div")(() => ({
  display: "flex",
  minHeight: "100vh",
  overflow: "hidden",
  width: "100%"
}));
const PageWrapper = (0,material_.experimentalStyled)("div")(({
  theme
}) => ({
  display: "flex",
  flex: "1 1 auto",
  overflow: "hidden",
  backgroundColor: theme.palette.background.default,
  [theme.breakpoints.up("lg")]: {
    paddingTop: "64px"
  },
  [theme.breakpoints.down("lg")]: {
    paddingTop: "64px"
  }
}));

const FullLayout = ({
  children
}) => {
  const [isSidebarOpen, setSidebarOpen] = external_react_default().useState(true);
  const [isMobileSidebarOpen, setMobileSidebarOpen] = external_react_default().useState(false);
  const customizer = (0,external_react_redux_.useSelector)(state => state.CustomizerReducer);
  const lgUp = (0,material_.useMediaQuery)(theme => theme.breakpoints.up("lg"));
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(MainWrapper, {
    children: [/*#__PURE__*/jsx_runtime_.jsx(header_Header, {
      sx: {
        paddingLeft: isSidebarOpen && lgUp ? "265px" : "",
        backgroundColor: customizer.activeMode === "dark" ? "#20232a" : "#fafbfb"
      },
      toggleSidebar: () => setSidebarOpen(!isSidebarOpen),
      toggleMobileSidebar: () => setMobileSidebarOpen(true)
    }), /*#__PURE__*/jsx_runtime_.jsx(sidebar_Sidebar, {
      isSidebardir: customizer.activeDir === "ltr" ? "left" : "right",
      isSidebarOpen: isSidebarOpen,
      isMobileSidebarOpen: isMobileSidebarOpen,
      onSidebarClose: () => setMobileSidebarOpen(false)
    }), /*#__PURE__*/jsx_runtime_.jsx(PageWrapper, {
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Container, {
        maxWidth: false,
        sx: {
          paddingTop: "20px",
          paddingLeft: isSidebarOpen && lgUp ? "280px!important" : ""
        },
        children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Box, {
          sx: {
            minHeight: "calc(100vh - 170px)"
          },
          children: children
        }), /*#__PURE__*/jsx_runtime_.jsx(customizer_Customizer, {}), /*#__PURE__*/jsx_runtime_.jsx(footer_Footer, {})]
      })
    })]
  });
};

/* harmony default export */ const layouts_FullLayout = (FullLayout);
;// CONCATENATED MODULE: ./src/layouts/BlankLayout.js



const BlankLayout = ({
  children
}) => {
  return /*#__PURE__*/jsx_runtime_.jsx(material_.Box, {
    children: children
  });
};

/* harmony default export */ const layouts_BlankLayout = (BlankLayout);
;// CONCATENATED MODULE: external "redux"
const external_redux_namespaceObject = require("redux");
;// CONCATENATED MODULE: external "redux-thunk"
const external_redux_thunk_namespaceObject = require("redux-thunk");
var external_redux_thunk_default = /*#__PURE__*/__webpack_require__.n(external_redux_thunk_namespaceObject);
;// CONCATENATED MODULE: ./src/store/customizer/CustomizerReducer.js
function CustomizerReducer_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function CustomizerReducer_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { CustomizerReducer_ownKeys(Object(source), true).forEach(function (key) { CustomizerReducer_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { CustomizerReducer_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function CustomizerReducer_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


const INIT_STATE = {
  activeDir: 'ltr',
  activeNavbarBg: '#0b70fb',
  // This can be any color,
  activeSidebarBg: '#ffffff',
  // This can be any color
  activeMode: 'light',
  // This can be light or dark
  activeTheme: 'ORANGE_THEME',
  // BLUE_THEME, GREEN_THEME, RED_THEME, BLACK_THEME, PURPLE_THEME, INDIGO_THEME
  SidebarWidth: 240
};

const CustomizerReducer = (state = INIT_STATE, action) => {
  switch (action.type) {
    case constants_NAVBAR_BG:
      return CustomizerReducer_objectSpread(CustomizerReducer_objectSpread({}, state), {}, {
        activeNavbarBg: action.payload
      });

    case DARK_THEME:
      return CustomizerReducer_objectSpread(CustomizerReducer_objectSpread({}, state), {}, {
        activeMode: action.payload
      });

    case constants_SIDEBAR_BG:
      return CustomizerReducer_objectSpread(CustomizerReducer_objectSpread({}, state), {}, {
        activeSidebarBg: action.payload
      });

    case THEME_COLOR:
      return CustomizerReducer_objectSpread(CustomizerReducer_objectSpread({}, state), {}, {
        activeTheme: action.payload
      });

    case DIRECTION:
      return CustomizerReducer_objectSpread(CustomizerReducer_objectSpread({}, state), {}, {
        activeDir: action.payload
      });

    default:
      return state;
  }
};

/* harmony default export */ const customizer_CustomizerReducer = (CustomizerReducer);
;// CONCATENATED MODULE: ./src/store/Rootreducers.js


const RootReducers = (0,external_redux_namespaceObject.combineReducers)({
  CustomizerReducer: customizer_CustomizerReducer
});
/* harmony default export */ const Rootreducers = (RootReducers);
;// CONCATENATED MODULE: external "next-redux-wrapper"
const external_next_redux_wrapper_namespaceObject = require("next-redux-wrapper");
;// CONCATENATED MODULE: ./src/store/Store.js





const makeStore = () => {
  return (0,external_redux_namespaceObject.createStore)(Rootreducers, (0,external_redux_namespaceObject.compose)((0,external_redux_namespaceObject.applyMiddleware)((external_redux_thunk_default()))));
};

/* harmony default export */ const Store = ((0,external_next_redux_wrapper_namespaceObject.createWrapper)(makeStore, {
  debug: true
}));
;// CONCATENATED MODULE: ./pages/_app.js
function _app_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _app_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { _app_ownKeys(Object(source), true).forEach(function (key) { _app_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { _app_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _app_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }














 // import "react-loader-spinner/dist/loader/css/react-spinner-loader.css";
// Client-side cache, shared for the whole session of the user in the browser.



const clientSideEmotionCache = (0,createEmotionCache/* default */.Z)();
const layouts = {
  Blank: layouts_BlankLayout
};

function MyApp(props) {
  const {
    Component,
    emotionCache = clientSideEmotionCache,
    pageProps
  } = props;
  const Gettheme = theme_ThemeSettings();
  const customizer = (0,external_react_redux_.useSelector)(state => state.CustomizerReducer);
  const Layout = layouts[Component.layout] || layouts_BlankLayout;
  const router = (0,router_.useRouter)();

  if (router.pathname.startsWith("/dashboard")) {
    return /*#__PURE__*/(0,jsx_runtime_.jsxs)(react_namespaceObject.CacheProvider, {
      value: emotionCache,
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)((head_default()), {
        children: [/*#__PURE__*/jsx_runtime_.jsx("title", {
          children: "rightNet - Easily Get Airtime and Data"
        }), /*#__PURE__*/jsx_runtime_.jsx("meta", {
          name: "viewport",
          content: "initial-scale=1, width=device-width"
        })]
      }), /*#__PURE__*/jsx_runtime_.jsx(styles_.ThemeProvider, {
        theme: Gettheme,
        children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(theme_RTL, {
          direction: customizer.activeDir,
          children: [/*#__PURE__*/jsx_runtime_.jsx((CssBaseline_default()), {}), /*#__PURE__*/jsx_runtime_.jsx(layouts_FullLayout, {
            children: /*#__PURE__*/jsx_runtime_.jsx(Component, _app_objectSpread({}, pageProps))
          })]
        })
      })]
    });
  } else {
    return /*#__PURE__*/(0,jsx_runtime_.jsxs)(react_namespaceObject.CacheProvider, {
      value: emotionCache,
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)((head_default()), {
        children: [/*#__PURE__*/jsx_runtime_.jsx("title", {
          children: "rightNet - Easily Get Airtime and Data"
        }), /*#__PURE__*/jsx_runtime_.jsx("meta", {
          name: "viewport",
          content: "initial-scale=1, width=device-width"
        })]
      }), /*#__PURE__*/jsx_runtime_.jsx(styles_.ThemeProvider, {
        theme: Gettheme,
        children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(theme_RTL, {
          direction: customizer.activeDir,
          children: [/*#__PURE__*/jsx_runtime_.jsx((CssBaseline_default()), {}), /*#__PURE__*/jsx_runtime_.jsx(Layout, {
            children: /*#__PURE__*/jsx_runtime_.jsx(Component, _app_objectSpread({}, pageProps))
          })]
        })
      })]
    });
  }
}

/* harmony default export */ const _app = (Store.withRedux(MyApp));

/***/ }),

/***/ 2803:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ createEmotionCache)
/* harmony export */ });
/* harmony import */ var _emotion_cache__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1913);
/* harmony import */ var _emotion_cache__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_emotion_cache__WEBPACK_IMPORTED_MODULE_0__);

function createEmotionCache() {
  return _emotion_cache__WEBPACK_IMPORTED_MODULE_0___default()({
    key: 'css'
  });
}

/***/ }),

/***/ 9220:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/user2.5f9a8dc0.jpg","height":200,"width":200,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAgACAMBIgACEQEDEQH/xAAoAAEBAAAAAAAAAAAAAAAAAAAABgEBAQAAAAAAAAAAAAAAAAAAAQT/2gAMAwEAAhADEAAAALsE/wD/xAAeEAABAQkAAAAAAAAAAAAAAAASFQABAwQREyEiM//aAAgBAQABPwB8xAVzU8crBalRv//EABcRAQADAAAAAAAAAAAAAAAAAAIAARH/2gAIAQIBAT8AKtbP/8QAGhEAAQUBAAAAAAAAAAAAAAAAAQACAxESIf/aAAgBAwEBPwCGZ0u7DRk1xf/Z"});

/***/ }),

/***/ 1913:
/***/ ((module) => {

module.exports = require("@emotion/cache");

/***/ }),

/***/ 5692:
/***/ ((module) => {

module.exports = require("@mui/material");

/***/ }),

/***/ 5374:
/***/ ((module) => {

module.exports = require("@mui/material/Radio");

/***/ }),

/***/ 8442:
/***/ ((module) => {

module.exports = require("@mui/material/styles");

/***/ }),

/***/ 738:
/***/ ((module) => {

module.exports = require("feather-icons-react");

/***/ }),

/***/ 562:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 8028:
/***/ ((module) => {

module.exports = require("next/dist/server/image-config.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 4365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 3018:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/to-base-64.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 6022:
/***/ ((module) => {

module.exports = require("react-redux");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [639,664,675,507,373,389], () => (__webpack_exec__(5600)));
module.exports = __webpack_exports__;

})();