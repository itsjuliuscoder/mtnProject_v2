"use strict";
exports.id = 918;
exports.ids = [918];
exports.modules = {

/***/ 5918:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Landing)
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(5692);
// EXTERNAL MODULE: ./styles/Component.module.css
var Component_module = __webpack_require__(1726);
var Component_module_default = /*#__PURE__*/__webpack_require__.n(Component_module);
// EXTERNAL MODULE: external "feather-icons-react"
var external_feather_icons_react_ = __webpack_require__(738);
var external_feather_icons_react_default = /*#__PURE__*/__webpack_require__.n(external_feather_icons_react_);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
;// CONCATENATED MODULE: ./src/constants/constant.js
const motionVariant = {
  hidden: {
    opacity: 0,
    x: -200,
    y: 0
  },
  enter: {
    opacity: 1,
    x: 0,
    y: 0,
    transition: {
      ease: "easeInOut",
      duration: .8
    }
  },
  exit: {
    opacity: 0,
    x: 0,
    y: -100
  }
};
const transition = {
  duration: 0.5,
  ease: "easeInOut"
};
const motionFadeInVariant = {
  initial: {
    y: 100,
    opacity: 0
  },
  enter: {
    y: 0,
    opacity: 1,
    transition
  },
  exit: {
    y: -100,
    opacity: 0,
    transition
  }
};
const delaytransition = {
  duration: 0.9,
  ease: "easeInOut"
};
const delayMotionFadeInVariant = {
  initial: {
    y: 100,
    opacity: 0
  },
  enter: {
    y: 0,
    opacity: 1,
    transition: delaytransition
  },
  exit: {
    y: -100,
    opacity: 0,
    transaction: delaytransition
  }
};
/* harmony default export */ const constant = ({
  motionVariant,
  motionFadeInVariant,
  delayMotionFadeInVariant
});
;// CONCATENATED MODULE: ./src/constants/index.js


// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: ./pages/landing.js










function Landing() {
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      // variants={ constant.motionVariant }
      // initial="hidden"
      // animate="enter"
      className: (Component_module_default()).banner_bg,
      children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Grid, {
        container: true,
        spacing: 0,
        children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Grid, {
          item: true,
          xs: 12,
          lg: 12,
          children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
            variant: "h1",
            fontWeight: "900",
            textAlign: "center",
            style: {
              fontSize: '48px'
            },
            children: "Welcome to RIGHTNET"
          }), /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
            variant: "h5",
            fontWeight: "900",
            textAlign: "center",
            children: "We offer services such as Data Bundle and Airtime TopUp, Bills Payments, Cable Subscription and lots more"
          })]
        })
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: (Component_module_default()).group__btn,
        children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Grid, {
          container: true,
          spacing: 2,
          children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Grid, {
            item: true,
            xs: 12,
            lg: 6,
            children: /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
              variant: "h5",
              fontWeight: "900",
              textAlign: "center",
              children: /*#__PURE__*/jsx_runtime_.jsx(next_link["default"], {
                href: "/authentication/login",
                children: /*#__PURE__*/jsx_runtime_.jsx(material_.Button, {
                  className: (Component_module_default()).create__account__4,
                  children: " Login To Continue "
                })
              })
            })
          }), /*#__PURE__*/jsx_runtime_.jsx(material_.Grid, {
            item: true,
            xs: 12,
            lg: 6,
            children: /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
              variant: "h5",
              fontWeight: "900",
              textAlign: "center",
              children: /*#__PURE__*/jsx_runtime_.jsx(next_link["default"], {
                href: "/authentication/login",
                children: /*#__PURE__*/jsx_runtime_.jsx(material_.Button, {
                  className: (Component_module_default()).create__account__3,
                  children: " Create An Account "
                })
              })
            })
          })]
        })
      })]
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: (Component_module_default()).row__style__3,
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: (Component_module_default()).container__style,
        children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
          variant: "h1",
          fontWeight: "900",
          textAlign: "center",
          style: {
            fontSize: '48px',
            marginBottom: '1em'
          },
          children: "Our Services"
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Grid, {
          container: true,
          spacing: 2,
          children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Grid, {
            item: true,
            xs: 12,
            lg: 4,
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: (Component_module_default()).never__runout_text__2,
              children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Box, {
                textAlign: "left",
                children: /*#__PURE__*/jsx_runtime_.jsx((external_feather_icons_react_default()), {
                  icon: "layers",
                  width: "50",
                  height: "50"
                })
              }), /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
                mt: "2",
                variant: "h4",
                fontWeight: "900",
                textAlign: "left",
                children: "Airtime TopUp"
              })]
            })
          }), /*#__PURE__*/jsx_runtime_.jsx(material_.Grid, {
            item: true,
            xs: 12,
            lg: 4,
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: (Component_module_default()).never__runout_text__2_2,
              children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Box, {
                textAlign: "left",
                children: /*#__PURE__*/jsx_runtime_.jsx((external_feather_icons_react_default()), {
                  icon: "database",
                  width: "50",
                  height: "50"
                })
              }), /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
                mt: "2",
                variant: "h4",
                fontWeight: "900",
                textAlign: "left",
                children: "Data Bundle Subscription"
              })]
            })
          }), /*#__PURE__*/jsx_runtime_.jsx(material_.Grid, {
            item: true,
            xs: 12,
            lg: 4,
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: (Component_module_default()).never__runout_text__2_3,
              children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Box, {
                textAlign: "left",
                children: /*#__PURE__*/jsx_runtime_.jsx((external_feather_icons_react_default()), {
                  icon: "cpu",
                  width: "50",
                  height: "50"
                })
              }), /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
                mt: "2",
                variant: "h4",
                fontWeight: "900",
                textAlign: "left",
                children: "Cable Subscription"
              })]
            })
          })]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Grid, {
          container: true,
          spacing: 2,
          children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Grid, {
            item: true,
            xs: 12,
            lg: 4,
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: (Component_module_default()).never__runout_text__2_5,
              children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Box, {
                textAlign: "left",
                children: /*#__PURE__*/jsx_runtime_.jsx((external_feather_icons_react_default()), {
                  icon: "move",
                  width: "50",
                  height: "50"
                })
              }), /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
                mt: "2",
                variant: "h4",
                fontWeight: "900",
                textAlign: "left",
                children: "Airtime To Cash"
              })]
            })
          }), /*#__PURE__*/jsx_runtime_.jsx(material_.Grid, {
            item: true,
            xs: 12,
            lg: 4,
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: (Component_module_default()).never__runout_text__2_4,
              children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Box, {
                textAlign: "left",
                children: /*#__PURE__*/jsx_runtime_.jsx((external_feather_icons_react_default()), {
                  icon: "layers",
                  width: "50",
                  height: "50"
                })
              }), /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
                mt: "2",
                variant: "h4",
                fontWeight: "900",
                textAlign: "left",
                children: "Utility Bills Payments"
              })]
            })
          }), /*#__PURE__*/jsx_runtime_.jsx(material_.Grid, {
            item: true,
            xs: 12,
            lg: 4,
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: (Component_module_default()).never__runout_text__2_7,
              children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Box, {
                textAlign: "left",
                children: /*#__PURE__*/jsx_runtime_.jsx((external_feather_icons_react_default()), {
                  icon: "layers",
                  width: "50",
                  height: "50"
                })
              }), /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
                mt: "2",
                variant: "h4",
                fontWeight: "900",
                textAlign: "left",
                children: "Borrow Airtime"
              })]
            })
          })]
        })]
      })
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: (Component_module_default()).row__style__2,
      children: /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: (Component_module_default()).container__style,
        children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Grid, {
          container: true,
          spacing: 2,
          children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Grid, {
            item: true,
            xs: 12,
            lg: 4,
            children: /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
              mt: "2",
              variant: "h1",
              fontWeight: "900",
              textAlign: "left",
              style: {
                fontSize: '42px'
              },
              children: "Secured E-Wallet Platform"
            })
          }), /*#__PURE__*/jsx_runtime_.jsx(material_.Grid, {
            item: true,
            xs: 12,
            lg: 8,
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Grid, {
              container: true,
              spacing: 2,
              children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Grid, {
                item: true,
                xs: 12,
                lg: 6,
                style: {
                  textAlign: "center"
                },
                children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Box, {
                  textAlign: "center",
                  style: {
                    backgroundColor: '#fff',
                    color: '#000',
                    width: '30%',
                    margin: '1em auto',
                    borderRadius: '22px',
                    padding: '9px'
                  },
                  children: /*#__PURE__*/jsx_runtime_.jsx((external_feather_icons_react_default()), {
                    icon: "key",
                    width: "70",
                    height: "70"
                  })
                }), /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
                  mt: "2",
                  variant: "p",
                  fontWeight: "500",
                  textAlign: "center",
                  style: {
                    margin: '1em auto'
                  },
                  children: "We adopt advance algorithm which helps us in verifying our users and their credit worthiness before they can be offering/requesting for loan"
                })]
              }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Grid, {
                item: true,
                xs: 12,
                lg: 6,
                style: {
                  textAlign: "center"
                },
                children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Box, {
                  textAlign: "center",
                  style: {
                    backgroundColor: '#fff',
                    color: '#000',
                    width: '30%',
                    margin: '1em auto',
                    borderRadius: '22px',
                    padding: '9px'
                  },
                  children: /*#__PURE__*/jsx_runtime_.jsx((external_feather_icons_react_default()), {
                    icon: "lock",
                    width: "70",
                    height: "70"
                  })
                }), /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
                  mt: "2",
                  variant: "p",
                  fontWeight: "500",
                  textAlign: "center",
                  style: {
                    textAlign: "center"
                  },
                  children: "RightNet places top priority on security and we adopt top level Internet Security which enable us encrypt information and it is completely protected from fraud."
                })]
              })]
            })
          })]
        })
      })
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: (Component_module_default()).row__steps,
      children: /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: (Component_module_default()).container__style,
        children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Grid, {
          container: true,
          spacing: 2,
          children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Grid, {
            item: true,
            xs: 12,
            lg: 6,
            children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Grid, {
              item: true,
              xs: 12,
              lg: 12,
              children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                className: (Component_module_default()).step_one,
                children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
                  variant: "h3",
                  fontWeight: "900",
                  textAlign: "left",
                  style: {
                    marginTop: '4em',
                    fontSize: '32px'
                  },
                  children: "Register to Get Started"
                }), /*#__PURE__*/jsx_runtime_.jsx("p", {
                  children: "To use RightNet services, you need to first register as a user."
                })]
              })
            }), /*#__PURE__*/jsx_runtime_.jsx(material_.Grid, {
              item: true,
              xs: 12,
              lg: 12,
              children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                className: (Component_module_default()).step_two,
                children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
                  variant: "h3",
                  fontWeight: "900",
                  textAlign: "left",
                  style: {
                    marginTop: '4em',
                    fontSize: '32px'
                  },
                  children: "Login to the E-Wallet Dashboard"
                }), /*#__PURE__*/jsx_runtime_.jsx("p", {
                  children: "After successfully registering, you are required to login to enable you access the wide range of services RightNet offers"
                })]
              })
            }), /*#__PURE__*/jsx_runtime_.jsx(material_.Grid, {
              item: true,
              xs: 12,
              lg: 12,
              children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                className: (Component_module_default()).step_three,
                children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
                  variant: "h3",
                  fontWeight: "900",
                  textAlign: "left",
                  style: {
                    marginTop: '4em',
                    fontSize: '32px'
                  },
                  children: "TopUp E-Wallet"
                }), /*#__PURE__*/jsx_runtime_.jsx("p", {
                  children: "After successfully registering, you are required to login to enable you access the wide range of services RightNet offers"
                })]
              })
            }), /*#__PURE__*/jsx_runtime_.jsx(material_.Grid, {
              item: true,
              xs: 12,
              lg: 12,
              children: /*#__PURE__*/jsx_runtime_.jsx("div", {
                className: (Component_module_default()).step_four,
                children: /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
                  variant: "h3",
                  fontWeight: "900",
                  textAlign: "left",
                  style: {
                    marginTop: '4em',
                    fontSize: '32px'
                  },
                  children: "Buy Airtime, Data"
                })
              })
            })]
          }), /*#__PURE__*/jsx_runtime_.jsx(material_.Grid, {
            item: true,
            xs: 12,
            lg: 6,
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              style: {
                margin: '15em auto'
              },
              children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
                mt: "2",
                variant: "h2",
                fontWeight: "900",
                children: "Create A RightNet Account Now"
              }), /*#__PURE__*/jsx_runtime_.jsx("div", {
                children: /*#__PURE__*/jsx_runtime_.jsx(next_link["default"], {
                  href: "/authentication/register",
                  children: /*#__PURE__*/jsx_runtime_.jsx(material_.Button, {
                    className: (Component_module_default()).create__account__2,
                    children: " Get Started Now! "
                  })
                })
              })]
            })
          })]
        })
      })
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: (Component_module_default()).getting__started,
      children: /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: (Component_module_default()).container__style,
        children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Grid, {
          container: true,
          spacing: 2,
          children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Grid, {
            item: true,
            xs: 12,
            lg: 8,
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: (Component_module_default()).top2,
              children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
                variant: "h5",
                children: "Get Started Now!"
              }), /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
                mt: "2",
                variant: "h1",
                fontWeight: "900",
                children: "Get Started In Minutes"
              })]
            })
          }), /*#__PURE__*/jsx_runtime_.jsx(material_.Grid, {
            item: true,
            xs: 12,
            lg: 4,
            children: /*#__PURE__*/jsx_runtime_.jsx("div", {
              className: (Component_module_default()).top2,
              children: /*#__PURE__*/jsx_runtime_.jsx(next_link["default"], {
                href: "/authentication/register",
                children: /*#__PURE__*/jsx_runtime_.jsx(material_.Button, {
                  className: (Component_module_default()).create__account,
                  children: " Create An Account "
                })
              })
            })
          })]
        })
      })
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: (Component_module_default()).footer__row,
      children: /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: (Component_module_default()).container__style,
        children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Grid, {
          container: true,
          spacing: 2,
          children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Grid, {
            item: true,
            xs: 12,
            lg: 4,
            children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
              mt: "2",
              variant: "h1",
              fontWeight: "900",
              children: "RightNet"
            }), /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
              mt: "2",
              variant: "h6",
              fontWeight: "900",
              children: "hello@rightnet.com.ng"
            }), /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
              mt: "2",
              variant: "h6",
              fontWeight: "900",
              children: "+234 9025015566"
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("ul", {
              className: (Component_module_default()).row__line,
              children: [/*#__PURE__*/jsx_runtime_.jsx("li", {
                children: /*#__PURE__*/jsx_runtime_.jsx((external_feather_icons_react_default()), {
                  icon: "facebook",
                  width: "24",
                  height: "24"
                })
              }), /*#__PURE__*/jsx_runtime_.jsx("li", {
                children: /*#__PURE__*/jsx_runtime_.jsx((external_feather_icons_react_default()), {
                  icon: "twitter",
                  width: "24",
                  height: "24"
                })
              }), /*#__PURE__*/jsx_runtime_.jsx("li", {
                children: /*#__PURE__*/jsx_runtime_.jsx((external_feather_icons_react_default()), {
                  icon: "instagram",
                  width: "24",
                  height: "24"
                })
              })]
            })]
          }), /*#__PURE__*/jsx_runtime_.jsx(material_.Grid, {
            item: true,
            xs: 12,
            lg: 8
          })]
        })
      })
    })]
  });
}

/***/ })

};
;