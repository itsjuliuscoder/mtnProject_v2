exports.id = 443;
exports.ids = [443];
exports.modules = {

/***/ 486:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ SuccessToaster)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3590);
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8819);
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _styles_Component_module_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1726);
/* harmony import */ var _styles_Component_module_css__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_styles_Component_module_css__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_toastify__WEBPACK_IMPORTED_MODULE_1__]);
react_toastify__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];





function SuccessToaster({
  title
}) {
  react_toastify__WEBPACK_IMPORTED_MODULE_1__.toast.success( /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("p", {
    className: (_styles_Component_module_css__WEBPACK_IMPORTED_MODULE_4___default().toaster__content),
    children: title
  }), {
    toastId: 'oleefe__toaster__success'
  });
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(react_toastify__WEBPACK_IMPORTED_MODULE_1__.ToastContainer, {
    icon: true
  });
}
});

/***/ }),

/***/ 1443:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2296);
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(formik__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5609);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(yup__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _custom_elements_CustomSelect__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9379);
/* harmony import */ var _custom_elements_CustomFormLabel__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5959);
/* harmony import */ var _custom_elements_CustomTextField__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1472);
/* harmony import */ var _styles_Component_module_css__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(1726);
/* harmony import */ var _styles_Component_module_css__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(_styles_Component_module_css__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1664);
/* harmony import */ var _dashboard_dashboard1_ErrorToaster__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(5732);
/* harmony import */ var _dashboard_dashboard1_SuccessToaster__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(486);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_dashboard_dashboard1_SuccessToaster__WEBPACK_IMPORTED_MODULE_10__, _dashboard_dashboard1_ErrorToaster__WEBPACK_IMPORTED_MODULE_9__]);
([_dashboard_dashboard1_SuccessToaster__WEBPACK_IMPORTED_MODULE_10__, _dashboard_dashboard1_ErrorToaster__WEBPACK_IMPORTED_MODULE_9__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);
















const initalValues = {
  phone_number: "",
  pin: ""
};

const CustomForm = ({
  data,
  acctype,
  services
}) => {
  const {
    0: open,
    1: setOpen
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
  const [amount, setAmount] = react__WEBPACK_IMPORTED_MODULE_0___default().useState("");
  const [phone, setPhonenumber] = react__WEBPACK_IMPORTED_MODULE_0___default().useState("");
  const [type, setType] = react__WEBPACK_IMPORTED_MODULE_0___default().useState("");
  const [dataType, setDataType] = react__WEBPACK_IMPORTED_MODULE_0___default().useState("");
  const [paymentType, setPaymentType] = react__WEBPACK_IMPORTED_MODULE_0___default().useState("");
  const [walletOperator, setWalletOperator] = react__WEBPACK_IMPORTED_MODULE_0___default().useState("");
  const [amountTP, setAmountTP] = react__WEBPACK_IMPORTED_MODULE_0___default().useState(0);
  const [balanceAmount, setBalanceAmount] = react__WEBPACK_IMPORTED_MODULE_0___default().useState(0);
  const [userData, setUserData] = react__WEBPACK_IMPORTED_MODULE_0___default().useState("");
  const [skipped, setSkipped] = react__WEBPACK_IMPORTED_MODULE_0___default().useState(new Set());
  const {
    0: response,
    1: setResponse
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
  const {
    0: errorResponse,
    1: setErrorResponse
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
  const [paymentDesc, setPaymentDesc] = react__WEBPACK_IMPORTED_MODULE_0___default().useState("");
  const [pin, setPin] = react__WEBPACK_IMPORTED_MODULE_0___default().useState(""); // const [ isloading, setIsloading ] = useState(true);

  const Router = (0,next_router__WEBPACK_IMPORTED_MODULE_11__.useRouter)();
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    retrieveUserDetails(); // getAllServices();
  }, []);
  const headers = {
    Accept: "application/json" // Authorization: accessToken ? accessToken : "No Auth"

  };

  const retrieveUserDetails = () => {
    // setIsloading(true);
    const headers = {
      Accept: "application/json" // Authorization: accessToken ? accessToken : "No Auth"

    };
    axios__WEBPACK_IMPORTED_MODULE_7___default()({
      method: 'post',
      url: 'https://mtn-backend-api-service.herokuapp.com/v1/auth/get_UserDetails',
      headers,
      data: {
        phone_number: data.phone_number,
        user_id: data._id
      }
    }).then(function (response) {
      console.log("this is the response data -->", response.data); // setIsloading(false);

      if (response.data.statusCode === "000") {
        // setUserResponseData(response.data.payload);
        setBalanceAmount(response.data.payload.wallet_balance); //setPinStatus(response.data.payload.isPin);
        //console.log("this is the balance --->", response.data.payload.wallet_balance);
      } else {
        console.log("this is the response gotten", response);
      }
    }).catch(error => {
      // setIsloading(false);
      console.log("this is the error response gotten", error); //setErrorResponse("Invalid Login Credentials");

      setTimeout(setEmptyAlert, 5000);
    });
  };

  const handleTransaction = payload => {
    setPin(payload.pin);
    const number = "0" + payload.phone_number;
    setPhonenumber(number);
    validatePIN(payload.pin);
  };

  const setTransactionAmount = e => {
    // console.log("this is the transaction amount", e);
    const amounttp = e * 0.03;
    const amounttpValue = e - amounttp;
    let phone_number = phone ? phone : "";
    console.log("this is the type value -->", type);
    console.log("this is the payment type -->", paymentType);
    console.log("this is the walletOperator -->", walletOperator);
    console.log("this is the amount -->", e);
    console.log("this is the amount to pay -->", amounttpValue);
    setAmount(e);
    data.acctype === "Merchant" ? setAmountTP(amounttpValue) : setAmountTP(e); // console.log("this is the amount to pay stored -->", amountTP);

    setPaymentDesc("You are purchasing an airtime of " + e + " for this phone number " + phone_number);
  };

  const setDataAmount = e => {
    console.log("this is the transaction amount", e);
    const amounttp = e * 0.03;
    const amounttpValue = e - amounttp;
    let phone_number = phone ? phone : "";
    console.log("this is the type value -->", type);
    console.log("this is the payment type -->", paymentType);
    console.log("this is the walletOperator -->", walletOperator);
    console.log("this is the amount -->", e);
    console.log("this is the amount to pay -->", amounttpValue);
    setAmount(e); // setDataType(e)

    data.acctype === "Merchant" ? setAmountTP(amounttpValue) : setAmountTP(e); // console.log("this is the amount to pay stored -->", amountTP);

    setPaymentDesc("You are purchasing an airtime of " + e + " for this phone number " + phone_number);
  };

  const completeAirtime = () => {
    axios__WEBPACK_IMPORTED_MODULE_7___default()({
      method: 'post',
      url: 'https://mtn-backend-api-service.herokuapp.com/v1/wallet/buyAirtime',
      headers,
      data: {
        transactionId: Math.floor(Math.random() * 2356472122),
        user_id: data._id,
        phone_number: data.phone_number,
        msisdn: phone,
        amount: parseInt(amount),
        amount_charged: amountTP,
        pin: pin // previous_balance: data && data.wallet_balance ? data.wallet_balance : " ",
        // description: "Wallet Top up with amount " + amount + " was successful"

      }
    }).then(function (response) {
      console.log("this is the response data -->", response.data); // setIsloading(false);

      if (response.data.statusCode === "0000") {
        setResponse(response.data.statusMessage);
        setTimeout(() => {
          Router.replace("/dashboards/dashboard1");
        }, 2000);
      } else {
        console.log("this is the response gotten", response);
        setErrorResponse("Unable to create PIN");
      }
    }).catch(error => {
      // setIsloading(false);
      console.log("this is the error response gotten", error);
      setTimeout(() => {
        Router.replace("/dashboards/dashboard1");
      }, 3000);
      setErrorResponse("Topup or bundle activation failed");
      setTimeout(setEmptyAlert, 5000);
    });
  };

  const validatePIN = transPin => {
    axios__WEBPACK_IMPORTED_MODULE_7___default()({
      method: 'post',
      url: 'https://mtn-backend-api-service.herokuapp.com/v1/wallet/pinValidation',
      headers,
      data: {
        user_id: data._id,
        phone_number: data.phone_number,
        pin: transPin
      }
    }).then(function (response) {
      console.log("this is the response data -->", response.data); // setIsloading(false);

      if (response.data.statusCode === "000") {
        setResponse(response.data.statusMessage); // return response.data.statusCode;

        if (balanceAmount >= amount) {
          setOpen(true);
        } else {
          setErrorResponse("Insufficient Balance, Kindly TopUp Wallet");
        }
      } else {
        console.log("this is the response gotten", response);
        setErrorResponse("PIN Validation failed");
        return response.data.statusCode;
      }
    }).catch(error => {
      // setIsloading(false);
      console.log("this is the error response gotten", error);
      setErrorResponse("Wrong PIN entered, Enter a correct PIN");
      setTimeout(setEmptyAlert, 5000);
      return error;
    });
  };

  const completeData = () => {
    axios__WEBPACK_IMPORTED_MODULE_7___default()({
      method: 'post',
      url: 'https://mtn-backend-api-service.herokuapp.com/v1/wallet/buyData',
      headers,
      data: {
        transactionId: Math.floor(Math.random() * 98881228958813),
        user_id: data._id,
        phone_number: data.phone_number,
        msisdn: phone,
        amount: parseInt(amount),
        amount_charged: amountTP,
        pin: pin // previous_balance: data && data.wallet_balance ? data.wallet_balance : " ",
        // description: "Wallet Top up with amount " + amount + " was successful"

      }
    }).then(function (response) {
      console.log("this is the response data -->", response.data); // setIsloading(false);

      if (response.data.statusCode === "0000") {
        setResponse(response.data.statusMessage);
        setTimeout(() => {
          Router.replace("/dashboards/dashboard1");
        }, 2000);
      } else {
        console.log("this is the response gotten", response);
        setErrorResponse("Data Top Up Failed");
      }
    }).catch(error => {
      // setIsloading(false);
      console.log("this is the error response gotten", error);
      setTimeout(() => {
        Router.replace("/dashboards/dashboard1");
      }, 3000);
      setErrorResponse("Data Top Up Failed");
      setTimeout(setEmptyAlert, 5000);
    });
  };

  const handleClose = () => {
    setOpen(false);
  };

  const setEmptyAlert = () => {
    setResponse("");
    setErrorResponse("");
  };

  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.Fragment, {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx("div", {
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Modal, {
        open: open,
        onClose: handleClose,
        "aria-labelledby": "modal-modal-title",
        "aria-describedby": "modal-modal-description",
        children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Box, {
          className: (_styles_Component_module_css__WEBPACK_IMPORTED_MODULE_13___default().modal___window__3),
          children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Typography, {
            id: "modal-modal-title",
            variant: "h6",
            component: "h2",
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx("h2", {
              children: "Transaction Details"
            }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)("p", {
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx("b", {
                children: "Amount: "
              }), amount]
            }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)("p", {
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx("b", {
                children: "Amount To Pay: "
              }), amountTP]
            }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)("p", {
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx("b", {
                children: "Payment Description: "
              }), paymentDesc]
            })]
          }), acctype && acctype == "airtime" ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Button, {
            onClick: completeAirtime,
            sx: {
              mt: 2
            },
            variant: "contained",
            color: "success",
            children: "Buy Airtime"
          }) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Button, {
            onClick: completeData,
            sx: {
              mt: 2
            },
            variant: "contained",
            color: "success",
            children: "Buy Data"
          })]
        })
      })
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Card, {
      sx: {
        p: 0
      },
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Box, {
        sx: {
          padding: '15px 30px'
        },
        display: "flex",
        alignItems: "center",
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Box, {
          flexGrow: 1,
          children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Typography, {
            variant: "h3",
            children: ["Hi ", data.firstname, ", Buy Your ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx("b", {
              children: acctype ? acctype : ""
            })]
          })
        })
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Divider, {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.CardContent, {
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(formik__WEBPACK_IMPORTED_MODULE_1__.Formik, {
          initialValues: initalValues,
          validationSchema: (0,yup__WEBPACK_IMPORTED_MODULE_2__.object)({
            phone_number: (0,yup__WEBPACK_IMPORTED_MODULE_2__.string)().required("Please enter phone number").min(10, "Not a valid number").max(10, "Not a valid number"),
            pin: (0,yup__WEBPACK_IMPORTED_MODULE_2__.string)().required("Please enter pin").min(4, "Name too short").max(4, "Not more than 4 digit")
          }),
          onSubmit: (values, formikHelpers) => {
            handleTransaction(values); // console.log(values);

            formikHelpers.resetForm();
          },
          children: ({
            errors,
            isValid,
            touched,
            dirty
          }) => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(formik__WEBPACK_IMPORTED_MODULE_1__.Form, {
            children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {
              container: true,
              spacing: 2,
              children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {
                item: true,
                xs: 12,
                lg: 6,
                children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_custom_elements_CustomFormLabel__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                  htmlFor: "Payment",
                  children: "Select Type"
                }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(_custom_elements_CustomSelect__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                  labelId: "demo-simple-select-label",
                  id: "demo-simple-select" // value={acctype}
                  // onChange={handleChange}
                  ,
                  fullWidth: true,
                  size: "small",
                  onChange: e => setType(e.target.value),
                  children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.MenuItem, {
                    value: "VTU",
                    children: "VTU(Airtime & Data)"
                  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.MenuItem, {
                    value: "EPIN",
                    children: "EPIN"
                  })]
                })]
              }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {
                item: true,
                xs: 12,
                lg: 6,
                children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_custom_elements_CustomFormLabel__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                  htmlFor: "Payment",
                  children: "Select Payment Method"
                }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(_custom_elements_CustomSelect__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                  labelId: "demo-simple-select-label",
                  id: "demo-simple-select" // value={acctype}
                  // onChange={handleChange}
                  ,
                  fullWidth: true,
                  size: "small",
                  onChange: e => setPaymentType(e.target.value),
                  children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.MenuItem, {
                    value: "Wallet",
                    children: "Wallet"
                  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.MenuItem, {
                    value: "Bonus",
                    children: "Bonus"
                  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.MenuItem, {
                    value: "Card",
                    children: "Card"
                  })]
                })]
              }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {
                item: true,
                xs: 12,
                lg: 6,
                children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_custom_elements_CustomFormLabel__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                  htmlFor: "Email",
                  children: "Select Network Provider"
                }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(_custom_elements_CustomSelect__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                  labelId: "demo-simple-select-label",
                  id: "demo-simple-select" // onChange={handleChange}
                  ,
                  fullWidth: true,
                  size: "small",
                  onChange: e => setWalletOperator(e.target.value),
                  children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.MenuItem, {
                    value: "MTN",
                    children: "MTN"
                  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.MenuItem, {
                    value: "AIRTEL",
                    children: "AIRTEL"
                  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.MenuItem, {
                    value: "9MOBILE",
                    children: "9MOBILE"
                  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.MenuItem, {
                    value: "GLO",
                    children: "GLO"
                  })]
                })]
              }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {
                item: true,
                xs: 12,
                lg: 6,
                children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_custom_elements_CustomFormLabel__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                  htmlFor: "Email",
                  children: "Enter Phone number"
                }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(formik__WEBPACK_IMPORTED_MODULE_1__.Field, {
                  name: "phone_number",
                  type: "number",
                  as: _mui_material__WEBPACK_IMPORTED_MODULE_3__.TextField,
                  variant: "outlined",
                  color: "primary",
                  label: "Phone number",
                  fullWidth: true //onChange={e => setPhonenumber(e.target.value)} 
                  ,
                  error: Boolean(errors.phone_number) && Boolean(touched.phone_number),
                  helperText: Boolean(touched.phone_number) && errors.phone_number
                })]
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {
                item: true,
                xs: 12,
                lg: 6,
                children: acctype == "airtime" ? /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)("div", {
                  children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_custom_elements_CustomFormLabel__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                    htmlFor: "Email",
                    children: "Enter Amount"
                  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(formik__WEBPACK_IMPORTED_MODULE_1__.Field, {
                    name: "amount",
                    type: "number",
                    as: _mui_material__WEBPACK_IMPORTED_MODULE_3__.TextField,
                    variant: "outlined",
                    color: "primary",
                    label: "Amount",
                    fullWidth: true,
                    onChange: e => setTransactionAmount(e.target.value),
                    required: true
                  })]
                }) : /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.Fragment, {
                  children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_custom_elements_CustomFormLabel__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                    htmlFor: "Email",
                    children: "Select Data Offer"
                  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(_custom_elements_CustomSelect__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                    labelId: "demo-simple-select-label",
                    id: "demo-simple-select" // value={acctype}
                    // onChange={handleChange}
                    ,
                    fullWidth: true,
                    size: "small",
                    onChange: e => setDataAmount(e.target.value),
                    children: [services && services.length > 0 && services.map(service => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.MenuItem, {
                      value: service.amount,
                      children: service.name
                    }, service.id)), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.MenuItem, {
                      value: "EPIN",
                      children: "EPIN"
                    })]
                  })]
                })
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {
                item: true,
                xs: 12,
                lg: 6,
                children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.Fragment, {
                  children: data.isPin == true ? /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)("div", {
                    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_custom_elements_CustomFormLabel__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                      htmlFor: "Email",
                      children: "Enter Transaction PIN"
                    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(formik__WEBPACK_IMPORTED_MODULE_1__.Field, {
                      name: "pin",
                      type: "password",
                      as: _mui_material__WEBPACK_IMPORTED_MODULE_3__.TextField,
                      variant: "outlined",
                      color: "primary",
                      label: "pin",
                      fullWidth: true,
                      error: Boolean(errors.pin) && Boolean(touched.pin),
                      helperText: Boolean(touched.pin) && errors.pin
                    })]
                  }) : /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Box, {
                    sx: {
                      mt: 6
                    },
                    children: [" Kindly Create Your Transaction PIN to complete this transaction by ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(next_link__WEBPACK_IMPORTED_MODULE_8__["default"], {
                      href: "/dashboards/set-pin",
                      children: "Clicking Me"
                    }), "  "]
                  })
                })
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {
                item: true,
                xs: 12,
                lg: 6,
                children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Button, {
                  type: "submit",
                  variant: "contained",
                  color: "primary",
                  size: "large",
                  disabled: !isValid || !dirty,
                  children: "Purchase"
                })
              })]
            })
          })
        })
      })]
    }), errorResponse && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_dashboard_dashboard1_ErrorToaster__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
      title: errorResponse
    }), response && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_dashboard_dashboard1_SuccessToaster__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
      title: response
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CustomForm);
});

/***/ }),

/***/ 8819:
/***/ (() => {



/***/ })

};
;