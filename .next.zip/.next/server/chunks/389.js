"use strict";
exports.id = 389;
exports.ids = [389];
exports.modules = {

/***/ 4389:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ logo_LogoIcon)
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(5692);
// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(6022);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
;// CONCATENATED MODULE: ./assets/images/logos/logo-dark.svg
/* harmony default export */ const logo_dark = ({"src":"/_next/static/media/logo-dark.ff9ceee8.svg","height":38,"width":106});
;// CONCATENATED MODULE: ./assets/images/logos/logo-white.svg
/* harmony default export */ const logo_white = ({"src":"/_next/static/media/logo-white.191d11a6.svg","height":38,"width":106});
;// CONCATENATED MODULE: ./assets/images/logos/RN.png
/* harmony default export */ const RN = ({"src":"/_next/static/media/RN.e10ee535.png","height":78,"width":100,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAAAAADbboAnAAAAQUlEQVR42gE2AMn/ALxXhfbvaHbuAIaPeLitioqXAOrn5dze4ujqAPDl3ebk4enwAICrlLilp6WKALXKw83Fxse6oO8jTutmqv8AAAAASUVORK5CYII="});
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: ./src/layouts/logo/LogoIcon.js









const LogoIcon = () => {
  const customizer = (0,external_react_redux_.useSelector)(state => state.CustomizerReducer);
  return /*#__PURE__*/jsx_runtime_.jsx(material_.Link, {
    href: "/",
    children: customizer.activeMode === "dark" ? /*#__PURE__*/jsx_runtime_.jsx(next_image["default"], {
      src: RN,
      alt: logo_white
    }) : /*#__PURE__*/jsx_runtime_.jsx(next_image["default"], {
      src: RN,
      alt: logo_dark
    })
  });
};

/* harmony default export */ const logo_LogoIcon = (LogoIcon);

/***/ })

};
;