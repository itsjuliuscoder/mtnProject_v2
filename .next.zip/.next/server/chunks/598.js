"use strict";
exports.id = 598;
exports.ids = [598];
exports.modules = {

/***/ 3598:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1664);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5675);
/* harmony import */ var _mui_material_Alert__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3765);
/* harmony import */ var _mui_material_Alert__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Alert__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _mui_icons_material_Google__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4492);
/* harmony import */ var _mui_icons_material_Google__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Google__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _mui_icons_material_Facebook__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7666);
/* harmony import */ var _mui_icons_material_Facebook__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Facebook__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _mui_icons_material_Twitter__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5631);
/* harmony import */ var _mui_icons_material_Twitter__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Twitter__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _src_components_forms_custom_elements_CustomCheckbox__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(4383);
/* harmony import */ var _src_components_forms_custom_elements_CustomTextField__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1472);
/* harmony import */ var _src_components_dashboard_dashboard1_ErrorToaster__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(5732);
/* harmony import */ var _src_components_forms_custom_elements_CustomFormLabel__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(5959);
/* harmony import */ var react_spinners_MoonLoader__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(6729);
/* harmony import */ var react_spinners_MoonLoader__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(react_spinners_MoonLoader__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _assets_images_backgrounds_login_bg_svg__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(9962);
/* harmony import */ var _assets_images_backgrounds_login2_png__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(9766);
/* harmony import */ var _src_layouts_logo_LogoIcon__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(4389);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_src_components_dashboard_dashboard1_ErrorToaster__WEBPACK_IMPORTED_MODULE_11__]);
_src_components_dashboard_dashboard1_ErrorToaster__WEBPACK_IMPORTED_MODULE_11__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];

















 // const validationSchema = yup.object({
//   email: yup
//     .string('Enter your email')
//     .email('Enter a valid email')
//     .required('Email is required'),
//   password: yup
//     .string('Enter your password')
//     .min(8, 'Password should be of minimum 8 characters length')
//     .required('Password is required'),
// });




const Login = () => {
  const router = (0,next_router__WEBPACK_IMPORTED_MODULE_1__.useRouter)();
  const {
    0: phone_number,
    1: setPhonenumber
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
  const {
    0: password,
    1: setPassword
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
  const {
    0: response,
    1: setResponse
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
  const {
    0: errorResponse,
    1: setErrorResponse
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
  const {
    0: isloading,
    1: setIsloading
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);

  const handleSubmit = e => {
    setIsloading(true);
    e.preventDefault();
    console.log("this are the data -->", phone_number, password);
    axios__WEBPACK_IMPORTED_MODULE_17___default()({
      method: 'post',
      url: 'https://mtn-backend-api-service.herokuapp.com/v1/auth/login',
      data: {
        phone_number: phone_number,
        password: password
      }
    }).then(function (response) {
      console.log("this is the response data -->", response.data);
      setIsloading(false);

      if (response.data.statusCode === "000") {
        router.push('/dashboards/dashboard1');
        setResponse(response.data.statusMessage);
        const token = response.data.accessToken;
        const data = response.data;

        if (response.data && response.data.payload) {
          localStorage.setItem('userToken', token);
          localStorage.setItem('userData', JSON.stringify(data.payload));
        }
      } else {
        console.log("this is the response gotten", response);
      }
    }).catch(error => {
      setIsloading(false);
      console.log("this is the error response gotten");
      setErrorResponse("Invalid Login Credentials");
      setTimeout(setEmptyAlert, 5000);
    });
  };

  const setEmptyAlert = () => {
    setResponse("");
    setErrorResponse("");
  };

  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
    container: true,
    sx: {
      height: "100vh",
      justifyContent: "center"
    },
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
      item: true,
      xs: 12,
      sm: 12,
      lg: 6,
      sx: {
        background: theme => `${theme.palette.mode === "dark" ? "#1c1f25" : "#ffffff"}`
      },
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, {
        sx: {
          position: "relative"
        },
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, {
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          sx: {
            position: {
              xs: "relative",
              lg: "absolute"
            },
            height: {
              xs: "auto",
              lg: "100vh"
            },
            right: {
              xs: "auto",
              lg: "-50px"
            },
            margin: "0 auto"
          },
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(next_image__WEBPACK_IMPORTED_MODULE_4__["default"], {
            src: _assets_images_backgrounds_login2_png__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z,
            alt: "bg",
            maxWidth: "812"
          })
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, {
          sx: {
            p: 4,
            position: "absolute",
            top: "0"
          },
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_src_layouts_logo_LogoIcon__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z, {})
        })]
      })
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
      item: true,
      xs: 12,
      sm: 8,
      lg: 6,
      display: "flex",
      alignItems: "center",
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
        container: true,
        spacing: 0,
        display: "flex",
        justifyContent: "center",
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
          item: true,
          xs: 12,
          lg: 9,
          xl: 6,
          children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, {
            sx: {
              p: 4
            },
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
              fontWeight: "700",
              variant: "h2",
              children: "Welcome to RightNet"
            }), errorResponse && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_src_components_dashboard_dashboard1_ErrorToaster__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
              title: errorResponse
            }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, {
              display: "flex",
              alignItems: "center",
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                color: "textSecondary",
                variant: "h6",
                fontWeight: "500",
                sx: {
                  mr: 1
                },
                children: "New to rightNet?"
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(next_link__WEBPACK_IMPORTED_MODULE_3__["default"], {
                href: "/authentication/register",
                children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                  fontWeight: "500",
                  sx: {
                    display: "block",
                    textDecoration: "none",
                    color: "primary.main",
                    cursor: "pointer"
                  },
                  children: "Create an account"
                })
              })]
            }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, {
              sx: {
                mt: 4
              },
              children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxs)("form", {
                onSubmit: handleSubmit,
                children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_src_components_forms_custom_elements_CustomFormLabel__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                  htmlFor: "phone_number",
                  children: "Phone Number"
                }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_src_components_forms_custom_elements_CustomTextField__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                  type: "number",
                  placeholder: "Enter Phone Number",
                  name: "phone_number",
                  id: "phone_number",
                  variant: "outlined",
                  fullWidth: true,
                  required: true,
                  value: phone_number,
                  onChange: e => setPhonenumber(e.target.value)
                }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_src_components_forms_custom_elements_CustomFormLabel__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                  htmlFor: "password",
                  children: "Password"
                }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_src_components_forms_custom_elements_CustomTextField__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                  name: "password",
                  placeholder: "Enter Password",
                  id: "password",
                  type: "password",
                  variant: "outlined",
                  fullWidth: true,
                  value: password,
                  onChange: e => setPassword(e.target.value),
                  required: true,
                  sx: {
                    mb: 3
                  }
                }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, {
                  sx: {
                    display: {
                      xs: "block",
                      sm: "flex",
                      lg: "flex"
                    },
                    alignItems: "center"
                  },
                  children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, {
                    sx: {
                      ml: "auto"
                    },
                    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(next_link__WEBPACK_IMPORTED_MODULE_3__["default"], {
                      href: "/authentication/reset-password",
                      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                        fontWeight: "500",
                        sx: {
                          display: "block",
                          textDecoration: "none",
                          mb: "16px",
                          color: "primary.main",
                          cursor: "pointer"
                        },
                        children: "Forgot Password ?"
                      })
                    })
                  })
                }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Button, {
                  type: "submit",
                  color: "secondary",
                  variant: "contained",
                  size: "large",
                  fullWidth: true,
                  sx: {
                    pt: "10px",
                    pb: "10px"
                  },
                  onClick: () => setIsloading(!isloading),
                  children: isloading ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx((react_spinners_MoonLoader__WEBPACK_IMPORTED_MODULE_13___default()), {
                    color: "#fff",
                    loading: isloading,
                    size: 30
                  }) : 'Sign In'
                })]
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, {
                sx: {
                  position: "relative",
                  textAlign: "center",
                  mt: "20px",
                  mb: "20px",
                  "&::before": {
                    content: '""',
                    background: theme => `${theme.palette.mode === "dark" ? "#42464d" : "#ecf0f2"}`,
                    height: "1px",
                    width: "100%",
                    position: "absolute",
                    left: "0",
                    top: "13px"
                  }
                },
                children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                  component: "span",
                  color: "textSecondary",
                  variant: "h6",
                  fontWeight: "400",
                  sx: {
                    position: "relative",
                    padding: "0 12px",
                    background: theme => `${theme.palette.mode === "dark" ? "#282c34" : "#fff"}`
                  },
                  children: "or sign in with"
                })
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, {
                children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Button, {
                  variant: "outlined",
                  size: "large",
                  display: "flex",
                  alignitems: "center",
                  justifycontent: "center",
                  sx: {
                    width: "100%",
                    borderColor: theme => `${theme.palette.mode === "dark" ? "#42464d" : "#dde3e8"}`,
                    borderWidth: "2px",
                    textAlign: "center",
                    mt: 2,
                    pt: "10px",
                    pb: "10px",
                    "&:hover": {
                      borderColor: theme => `${theme.palette.mode === "dark" ? "#42464d" : "#dde3e8"}`,
                      borderWidth: "2px"
                    }
                  },
                  children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, {
                    display: "flex",
                    alignItems: "center",
                    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx((_mui_icons_material_Google__WEBPACK_IMPORTED_MODULE_6___default()), {
                      sx: {
                        color: theme => theme.palette.error.main
                      }
                    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                      variant: "h6",
                      sx: {
                        ml: 1,
                        color: theme => `${theme.palette.mode === "dark" ? theme.palette.grey.A200 : "#13152a"}`
                      },
                      children: "Google"
                    })]
                  })
                })
              }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                container: true,
                spacing: 2,
                children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                  item: true,
                  xs: 12,
                  sm: 6,
                  lg: 6,
                  children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Button, {
                    variant: "outlined",
                    size: "large",
                    display: "flex",
                    alignitems: "center",
                    justifycontent: "center",
                    sx: {
                      width: "100%",
                      borderColor: theme => `${theme.palette.mode === "dark" ? "#42464d" : "#dde3e8"}`,
                      borderWidth: "2px",
                      textAlign: "center",
                      mt: 2,
                      pt: "10px",
                      pb: "10px",
                      "&:hover": {
                        borderColor: theme => `${theme.palette.mode === "dark" ? "#42464d" : "#dde3e8"}`,
                        borderWidth: "2px"
                      }
                    },
                    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, {
                      display: "flex",
                      alignItems: "center",
                      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx((_mui_icons_material_Facebook__WEBPACK_IMPORTED_MODULE_7___default()), {
                        sx: {
                          color: theme => theme.palette.secondary.main
                        }
                      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                        variant: "h6",
                        sx: {
                          ml: 1,
                          color: theme => `${theme.palette.mode === "dark" ? theme.palette.grey.A200 : "#13152a"}`
                        },
                        children: "Facebook"
                      })]
                    })
                  })
                }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                  item: true,
                  xs: 12,
                  sm: 6,
                  lg: 6,
                  children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Button, {
                    variant: "outlined",
                    size: "large",
                    display: "flex",
                    alignitems: "center",
                    justifycontent: "center",
                    sx: {
                      width: "100%",
                      borderColor: theme => `${theme.palette.mode === "dark" ? "#42464d" : "#dde3e8"}`,
                      borderWidth: "2px",
                      textAlign: "center",
                      mt: 2,
                      pt: "10px",
                      pb: "10px",
                      "&:hover": {
                        borderColor: theme => `${theme.palette.mode === "dark" ? "#42464d" : "#dde3e8"}`,
                        borderWidth: "2px"
                      }
                    },
                    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, {
                      display: "flex",
                      alignItems: "center",
                      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx((_mui_icons_material_Twitter__WEBPACK_IMPORTED_MODULE_8___default()), {
                        sx: {
                          color: theme => theme.palette.primary.main
                        }
                      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                        variant: "h6",
                        sx: {
                          ml: 1,
                          color: theme => `${theme.palette.mode === "dark" ? theme.palette.grey.A200 : "#13152a"}`
                        },
                        children: "Twitter"
                      })]
                    })
                  })
                })]
              })]
            })]
          })
        })
      })
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Login);
});

/***/ }),

/***/ 5732:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Toaster)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3590);
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8819);
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _styles_Component_module_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1726);
/* harmony import */ var _styles_Component_module_css__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_styles_Component_module_css__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_toastify__WEBPACK_IMPORTED_MODULE_1__]);
react_toastify__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];





function Toaster({
  title
}) {
  react_toastify__WEBPACK_IMPORTED_MODULE_1__.toast.error( /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("p", {
    className: (_styles_Component_module_css__WEBPACK_IMPORTED_MODULE_4___default().toaster__content),
    children: title
  }), {
    toastId: 'oleefe__toaster__error'
  });
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(react_toastify__WEBPACK_IMPORTED_MODULE_1__.ToastContainer, {
    icon: true
  });
}
});

/***/ }),

/***/ 9962:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/login-bg.394e92cf.svg","height":535,"width":812});

/***/ }),

/***/ 9766:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/login2.d97ff10a.png","height":924,"width":1640,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAFCAIAAAD38zoCAAAAZklEQVR42mP4hwT+////4f3779+/AxkMP3/+/PjxI5CESBzZvunUoQMIid+/f/8FgX8HDxxdMmv2m6dPGH79+vUZDL5///b69ZvF02dv3XHg/IXLDP+RwNevX29cv/no8bPPn78AAHh8brhiTM77AAAAAElFTkSuQmCC"});

/***/ })

};
;