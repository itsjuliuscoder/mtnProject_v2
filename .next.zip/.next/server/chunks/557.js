"use strict";
exports.id = 557;
exports.ids = [557];
exports.modules = {

/***/ 8372:
/***/ ((__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) => {


// UNUSED EXPORTS: default

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
// EXTERNAL MODULE: external "feather-icons-react"
var external_feather_icons_react_ = __webpack_require__(738);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(5692);
;// CONCATENATED MODULE: ./assets/images/backgrounds/blog-bg2-2x.jpg
/* harmony default export */ const blog_bg2_2x = ({"src":"/_next/static/media/blog-bg2-2x.9d7391ab.jpg","height":410,"width":722,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAUACAMBIgACEQEDEQH/xAAoAAEBAAAAAAAAAAAAAAAAAAAABwEBAQAAAAAAAAAAAAAAAAAABAX/2gAMAwEAAhADEAAAAKECVv/EABoQAQABBQAAAAAAAAAAAAAAAAERAAISEzH/2gAIAQEAAT8AuHYOTEcr/8QAFhEBAQEAAAAAAAAAAAAAAAAAAQAR/9oACAECAQE/AF2//8QAFhEBAQEAAAAAAAAAAAAAAAAAAQAC/9oACAEDAQE/AMgF/9k="});
// EXTERNAL MODULE: ./assets/images/users/1.jpg
var _1 = __webpack_require__(7574);
// EXTERNAL MODULE: ./assets/images/users/2.jpg
var _2 = __webpack_require__(791);
// EXTERNAL MODULE: ./assets/images/users/3.jpg
var _3 = __webpack_require__(6430);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: ./src/components/dashboard/dashboard1/BlogCard.js



 // images








const BlogCard = () => /*#__PURE__*/_jsxs(Card, {
  sx: {
    p: 0
  },
  children: [/*#__PURE__*/_jsx(Image, {
    src: background2x,
    alt: "img"
  }), /*#__PURE__*/_jsxs(CardContent, {
    sx: {
      paddingLeft: "30px",
      paddingRight: "30px"
    },
    children: [/*#__PURE__*/_jsxs(Box, {
      display: "flex",
      alignItems: "center",
      children: [/*#__PURE__*/_jsx(Typography, {
        color: "textSecondary",
        display: "flex",
        alignItems: "center",
        children: /*#__PURE__*/_jsx(FeatherIcon, {
          icon: "clock",
          width: "20",
          height: "20"
        })
      }), /*#__PURE__*/_jsx(Typography, {
        color: "textSecondary",
        variant: "subtitle2",
        sx: {
          ml: 1
        },
        children: "22 March, 2021"
      })]
    }), /*#__PURE__*/_jsx(Typography, {
      variant: "h4",
      sx: {
        mt: 3,
        pt: 1
      },
      children: "Super awesome, React 18 is coming soon!"
    }), /*#__PURE__*/_jsxs(Box, {
      display: "flex",
      alignItems: "center",
      sx: {
        mt: 2,
        pb: 3
      },
      children: [/*#__PURE__*/_jsx(Chip, {
        label: "Medium",
        size: "small",
        sx: {
          backgroundColor: theme => theme.palette.secondary.main,
          color: "#fff",
          pl: "3px",
          pr: "3px",
          borderRadius: "6px"
        }
      }), /*#__PURE__*/_jsx(Chip, {
        label: "Low",
        size: "small",
        sx: {
          backgroundColor: theme => theme.palette.error.main,
          color: "#fff",
          pl: "3px",
          pr: "3px",
          borderRadius: "6px",
          ml: 2
        }
      })]
    }), /*#__PURE__*/_jsx(Divider, {}), /*#__PURE__*/_jsxs(Box, {
      display: "flex",
      alignItems: "center",
      gap: 1,
      sx: {
        mt: 3
      },
      children: [/*#__PURE__*/_jsx(Image, {
        src: img1,
        alt: "blog",
        width: "40",
        height: "40",
        className: "roundedCircle"
      }), /*#__PURE__*/_jsx(Image, {
        src: img2,
        alt: "blog",
        width: "40",
        height: "40",
        className: "roundedCircle"
      }), /*#__PURE__*/_jsx(Image, {
        src: img3,
        alt: "blog",
        width: "40",
        height: "40",
        className: "roundedCircle"
      }), /*#__PURE__*/_jsx(Box, {
        sx: {
          ml: "auto"
        },
        children: /*#__PURE__*/_jsx(IconButton, {
          children: /*#__PURE__*/_jsx(FeatherIcon, {
            icon: "message-circle"
          })
        })
      })]
    })]
  })]
});

/* harmony default export */ const dashboard1_BlogCard = ((/* unused pure expression or super */ null && (BlogCard)));

/***/ }),

/***/ 7025:
/***/ ((__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) => {

/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var feather_icons_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(738);
/* harmony import */ var feather_icons_react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(feather_icons_react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_lab__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6072);
/* harmony import */ var _mui_lab__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_lab__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _baseCard_DashboardCard__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7802);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__);







const options = (/* unused pure expression or super */ null && (['Action', 'Another Action', 'Something else here']));
const activities = [{
  time: '09.50',
  color: 'success.main',
  text: 'Meeting with John'
}, {
  time: '09.46',
  color: 'secondary.main',
  text: 'Payment received of $385.90'
}, {
  time: '09.47',
  color: 'primary.main',
  text: 'Project Meeting'
}, {
  time: '09.48',
  color: 'warning.main',
  text: 'New Sale recorded #ML-3467'
}, {
  time: '09.49',
  color: 'error.main',
  text: 'Payment was made to Michael Anderson'
}];

const DailyActivities = () => {
  const [anchorEl, setAnchorEl] = React.useState(null);
  const open = Boolean(anchorEl);

  const handleClick = event => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  return /*#__PURE__*/_jsx(DashboardCard, {
    title: "Daily Activities",
    subtitle: "Overview of Years",
    action: /*#__PURE__*/_jsxs(Box, {
      children: [/*#__PURE__*/_jsx(Tooltip, {
        title: "Action",
        children: /*#__PURE__*/_jsx(IconButton, {
          "aria-expanded": open ? 'true' : undefined,
          "aria-haspopup": "true",
          onClick: handleClick,
          size: "large",
          "aria-label": "action",
          children: /*#__PURE__*/_jsx(FeatherIcon, {
            icon: "more-horizontal"
          })
        })
      }), /*#__PURE__*/_jsx(Menu, {
        id: "long-menu",
        MenuListProps: {
          'aria-labelledby': 'long-button'
        },
        anchorEl: anchorEl,
        open: open,
        onClose: handleClose,
        anchorOrigin: {
          vertical: 'bottom',
          horizontal: 'right'
        },
        transformOrigin: {
          vertical: 'top',
          horizontal: 'right'
        },
        children: options.map(option => /*#__PURE__*/_jsx(MenuItem, {
          selected: option === 'Pyxis',
          onClick: handleClose,
          children: option
        }, option))
      })]
    }),
    children: /*#__PURE__*/_jsx(Timeline, {
      sx: {
        p: 0,
        mb: 0,
        mt: 0
      },
      children: activities.map(activity => /*#__PURE__*/_jsxs(TimelineItem, {
        children: [/*#__PURE__*/_jsx(TimelineOppositeContent, {
          sx: {
            flex: '0'
          },
          children: /*#__PURE__*/_jsx(Typography, {
            variant: "subtitle2",
            fontWeight: "700",
            children: activity.time
          })
        }), /*#__PURE__*/_jsxs(TimelineSeparator, {
          children: [/*#__PURE__*/_jsx(TimelineDot, {
            variant: "outlined",
            sx: {
              borderColor: activity.color
            }
          }), /*#__PURE__*/_jsx(TimelineConnector, {})]
        }), /*#__PURE__*/_jsx(TimelineContent, {
          color: "text.secondary",
          variant: "h6",
          children: activity.text
        })]
      }, activity.time))
    })
  });
};

/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (DailyActivities)));

/***/ }),

/***/ 3457:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var feather_icons_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(738);
/* harmony import */ var feather_icons_react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(feather_icons_react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1664);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__);








const Earnings = ({
  data
}) => {
  const {
    0: open,
    1: setOpen
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
  const {
    0: openPinModal,
    1: setPinModal
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
  const {
    0: isloading,
    1: setIsloading
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true);
  const {
    0: userData,
    1: setUserData
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)("");
  const {
    0: response,
    1: setResponse
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
  const {
    0: errorResponse,
    1: setErrorResponse
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
  const {
    0: balanceAmount,
    1: setBalanceAmount
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)("");
  react__WEBPACK_IMPORTED_MODULE_0___default().useEffect(() => {
    setTimeout(() => setIsloading(false), 3000);
  });
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    const currentUser = JSON.parse(localStorage.getItem("userData"));
    const token = localStorage.getItem("userToken"); // setAccessToken(token);

    setUserData(currentUser);
    retrieveUserDetails(); // currentDate();
  }, []);

  const retrieveUserDetails = () => {
    setIsloading(true);
    const headers = {
      Accept: "application/json" // Authorization: accessToken ? accessToken : "No Auth"

    };
    axios__WEBPACK_IMPORTED_MODULE_4___default()({
      method: 'post',
      url: 'https://mtn-backend-api-service.herokuapp.com/v1/auth/get_UserDetails',
      headers,
      data: {
        phone_number: data.phone_number,
        user_id: data._id
      }
    }).then(function (response) {
      console.log("this is the response data -->", response.data);
      setIsloading(false);

      if (response.data.statusCode === "000") {
        // setUserResponseData(response.data.payload);
        setBalanceAmount(response.data.payload.wallet_balance);
      } else {
        console.log("this is the response gotten", response);
      }
    }).catch(error => {
      setIsloading(false);
      console.log("this is the error response gotten", error); //setErrorResponse("Invalid Login Credentials");

      setTimeout(setEmptyAlert, 5000);
    });
  };

  const setEmptyAlert = () => {
    setResponse("");
    setErrorResponse("");
  };

  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Card, {
    sx: {
      backgroundColor: theme => theme.palette.secondary.main,
      color: "white"
    },
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.CardContent, {
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, {
        display: "flex",
        alignItems: "flex-start",
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
          variant: "h3",
          sx: {
            marginBottom: "0"
          },
          gutterBottom: true,
          children: "Wallet"
        })
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
        variant: "h1",
        fontWeight: "500",
        sx: {
          marginBottom: "0",
          marginTop: "15px"
        },
        gutterBottom: true,
        children: ["\u20A6", data && balanceAmount ? balanceAmount : "0"]
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(next_link__WEBPACK_IMPORTED_MODULE_3__["default"], {
        href: "/dashboards/topup-wallet",
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Button, {
          sx: {
            marginTop: '15px'
          },
          variant: "contained",
          color: "primary",
          children: "Top Up Wallet"
        })
      })]
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Earnings);

/***/ }),

/***/ 3735:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ dashboard1_EarningsShop)
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
// EXTERNAL MODULE: external "feather-icons-react"
var external_feather_icons_react_ = __webpack_require__(738);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(5692);
;// CONCATENATED MODULE: ./assets/images/backgrounds/welcome-bg-2x-svg.svg
/* harmony default export */ const welcome_bg_2x_svg = ({"src":"/_next/static/media/welcome-bg-2x-svg.e795d7d8.svg","height":434,"width":1104});
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: ./src/components/dashboard/dashboard1/EarningsShop.js








const EarningsShop = ({
  title,
  color,
  logo,
  clickAction
}) => /*#__PURE__*/jsx_runtime_.jsx(material_.Card, {
  elevation: 0,
  sx: {
    position: 'relative',
    backgroundColor: `${color}`,
    '&:before': {
      content: `""`,
      position: 'absolute',
      left: theme => `${theme.direction === 'rtl' ? 'unset' : '0'}`,
      right: theme => `${theme.direction === 'rtl' ? '0' : 'unset'}`,
      width: '100%',
      height: '100%',
      background: `url(${welcome_bg_2x_svg})`,
      backgroundRepeat: 'no-repeat',
      backgroundSize: 'cover',
      transform: theme => `${theme.direction === 'rtl' ? 'scaleX(-1)' : 'unset'}`,
      backgroundPosition: theme => `${theme.direction === 'rtl' ? 'right 19px center' : 'left 70px center'}`
    },
    borderWidth: '0px'
  },
  children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.CardContent, {
    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Box, {
      display: "flex",
      alignItems: "center",
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Box, {
        children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
          fontWeight: "700",
          variant: "h4",
          color: "textSecondary"
        }), /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
          variant: "h3",
          children: title
        })]
      }), /*#__PURE__*/jsx_runtime_.jsx(material_.Box, {
        sx: {
          ml: 'auto'
        },
        children: /*#__PURE__*/jsx_runtime_.jsx(material_.Fab, {
          elevation: "0",
          color: "secondary",
          "aria-label": "dollar",
          sx: {
            color: '#fff',
            width: '90px',
            height: '90px'
          },
          children: /*#__PURE__*/jsx_runtime_.jsx(next_image["default"], {
            src: logo,
            width: "60",
            height: "60",
            alt: "logo"
          })
        })
      })]
    }), title == "MTN" ? /*#__PURE__*/jsx_runtime_.jsx(material_.Button, {
      sx: {
        marginTop: '15px',
        backgroundColor: '#000'
      },
      variant: "contained",
      onClick: clickAction,
      children: "Click Here"
    }) : /*#__PURE__*/jsx_runtime_.jsx(material_.Button, {
      sx: {
        marginTop: '15px',
        backgroundColor: '#000'
      },
      variant: "contained",
      children: "Click Here"
    })]
  })
});

/* harmony default export */ const dashboard1_EarningsShop = (EarningsShop);

/***/ }),

/***/ 435:
/***/ ((__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) => {

/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5675);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var feather_icons_react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(738);
/* harmony import */ var feather_icons_react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(feather_icons_react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _baseCard_DashboardCard__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7802);
/* harmony import */ var _assets_images_users_1_jpg__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7574);
/* harmony import */ var _assets_images_users_2_jpg__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(791);
/* harmony import */ var _assets_images_users_3_jpg__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6430);
/* harmony import */ var _assets_images_users_4_jpg__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(7326);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__);











const options = (/* unused pure expression or super */ null && (["Action", "Another Action", "Something else here"]));

const MedicalProBranding = () => {
  const [anchorEl, setAnchorEl] = React.useState(null);
  const open = Boolean(anchorEl);

  const handleClick = event => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  return /*#__PURE__*/_jsxs(DashboardCard, {
    title: "MedicalPro Branding",
    subtitle: "Branding & Website",
    action: /*#__PURE__*/_jsxs(Box, {
      children: [/*#__PURE__*/_jsx(Tooltip, {
        title: "Action",
        children: /*#__PURE__*/_jsx(IconButton, {
          "aria-expanded": open ? "true" : undefined,
          "aria-haspopup": "true",
          onClick: handleClick,
          size: "large",
          "aria-label": "action",
          children: /*#__PURE__*/_jsx(FeatherIcon, {
            icon: "more-horizontal"
          })
        })
      }), /*#__PURE__*/_jsx(Menu, {
        id: "long-menu",
        MenuListProps: {
          "aria-labelledby": "long-button"
        },
        anchorEl: anchorEl,
        open: open,
        onClose: handleClose,
        anchorOrigin: {
          vertical: "bottom",
          horizontal: "right"
        },
        transformOrigin: {
          vertical: "top",
          horizontal: "right"
        },
        children: options.map(option => /*#__PURE__*/_jsx(MenuItem, {
          selected: option === "Pyxis",
          onClick: handleClose,
          children: option
        }, option))
      })]
    }),
    children: [/*#__PURE__*/_jsx(Chip, {
      size: "small",
      label: "16 APR, 2021",
      sx: {
        backgroundColor: theme => theme.palette.primary.light,
        color: theme => theme.palette.primary.main,
        borderRadius: "6px",
        pl: 1,
        pr: 1,
        mt: -4
      }
    }), /*#__PURE__*/_jsxs(Box, {
      sx: {
        mt: 2
      },
      children: [/*#__PURE__*/_jsxs(Grid, {
        container: true,
        spacing: 0,
        children: [/*#__PURE__*/_jsxs(Grid, {
          item: true,
          xs: 4,
          lg: 4,
          sx: {
            borderRight: "1px solid rgba(0,0,0,0.1)",
            pb: 2
          },
          children: [/*#__PURE__*/_jsx(Typography, {
            color: "textSecondary",
            variant: "h6",
            fontWeight: "400",
            children: "Due Date"
          }), /*#__PURE__*/_jsx(Typography, {
            variant: "subtitle2",
            fontWeight: "500",
            children: "Oct 23, 2021"
          })]
        }), /*#__PURE__*/_jsxs(Grid, {
          item: true,
          xs: 4,
          lg: 4,
          sx: {
            borderRight: "1px solid rgba(0,0,0,0.1)",
            pb: 2,
            pl: 1
          },
          children: [/*#__PURE__*/_jsx(Typography, {
            color: "textSecondary",
            variant: "h6",
            fontWeight: "400",
            children: "Budget"
          }), /*#__PURE__*/_jsx(Typography, {
            variant: "subtitle2",
            fontWeight: "500",
            children: "$98,500"
          })]
        }), /*#__PURE__*/_jsxs(Grid, {
          item: true,
          xs: 4,
          lg: 4,
          sx: {
            pl: 1,
            pb: 2
          },
          children: [/*#__PURE__*/_jsx(Typography, {
            color: "textSecondary",
            variant: "h6",
            fontWeight: "400",
            children: "Expense"
          }), /*#__PURE__*/_jsx(Typography, {
            variant: "subtitle2",
            fontWeight: "500",
            children: "$63,000"
          })]
        })]
      }), /*#__PURE__*/_jsx(Divider, {})]
    }), /*#__PURE__*/_jsxs(Box, {
      sx: {
        pt: 2,
        pb: 3
      },
      children: [/*#__PURE__*/_jsx(Typography, {
        variant: "h4",
        children: "Teams"
      }), /*#__PURE__*/_jsxs(Box, {
        display: "flex",
        alignItems: "center",
        sx: {
          mt: 1
        },
        children: [/*#__PURE__*/_jsx(Chip, {
          size: "small",
          label: "Bootstrap",
          sx: {
            backgroundColor: theme => theme.palette.primary.main,
            color: "#fff",
            borderRadius: "6px",
            pl: 1,
            pr: 1
          }
        }), /*#__PURE__*/_jsx(Chip, {
          size: "small",
          label: "Angular",
          sx: {
            backgroundColor: theme => theme.palette.secondary.main,
            color: "#fff",
            borderRadius: "6px",
            pl: 1,
            pr: 1,
            ml: 1
          }
        })]
      })]
    }), /*#__PURE__*/_jsx(Divider, {}), /*#__PURE__*/_jsxs(Box, {
      sx: {
        pt: 2,
        pb: 2
      },
      children: [/*#__PURE__*/_jsx(Typography, {
        variant: "h4",
        children: "Leaders"
      }), /*#__PURE__*/_jsxs(Box, {
        display: "flex",
        gap: 1,
        alignItems: "center",
        sx: {
          mt: 1
        },
        children: [/*#__PURE__*/_jsx(Image, {
          width: "35",
          height: "35",
          className: "roundedCircle",
          src: img1,
          alt: img1
        }), /*#__PURE__*/_jsx(Image, {
          width: "35",
          height: "35",
          className: "roundedCircle",
          src: img2,
          alt: img2
        }), /*#__PURE__*/_jsx(Image, {
          width: "35",
          height: "35",
          className: "roundedCircle",
          src: img3,
          alt: img3
        }), /*#__PURE__*/_jsx(Image, {
          width: "35",
          height: "35",
          className: "roundedCircle",
          src: img4,
          alt: img4
        })]
      })]
    }), /*#__PURE__*/_jsx(Divider, {}), /*#__PURE__*/_jsxs(Box, {
      display: "flex",
      alignItems: "center",
      sx: {
        pt: 2
      },
      children: [/*#__PURE__*/_jsx(Button, {
        variant: "contained",
        color: "primary",
        children: "Add"
      }), /*#__PURE__*/_jsx(Box, {
        sx: {
          ml: "auto"
        },
        children: /*#__PURE__*/_jsx(Typography, {
          color: "textSecondary",
          variant: "h6",
          fontWeight: "400",
          children: "36 Recent Transactions"
        })
      })]
    })]
  });
};

/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (MedicalProBranding)));

/***/ }),

/***/ 5997:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5152);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8442);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material_styles__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var feather_icons_react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(738);
/* harmony import */ var feather_icons_react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(feather_icons_react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__);







const Chart = (0,next_dynamic__WEBPACK_IMPORTED_MODULE_1__["default"])(() => Promise.resolve(/* import() */).then(__webpack_require__.t.bind(__webpack_require__, 8403, 23)), {
  ssr: false,
  loadableGenerated: {
    webpack: () => [/*require.resolve*/(8403)],
    modules: ["..\\src\\components\\dashboard\\dashboard1\\MonthlySales.js -> " + "react-apexcharts"]
  }
});

const MonthlySales = ({
  data
}) => {
  const theme = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_2__.useTheme)();
  const primary = theme.palette.primary.main;
  const optionsmonthlychart = {
    grid: {
      show: true,
      borderColor: "transparent",
      strokeDashArray: 2,
      padding: {
        left: 0,
        right: 0,
        bottom: 0
      }
    },
    colors: [primary],
    chart: {
      toolbar: {
        show: false
      },
      foreColor: "#adb0bb",
      fontFamily: "'DM Sans',sans-serif",
      sparkline: {
        enabled: true
      }
    },
    dataLabels: {
      enabled: false
    },
    markers: {
      size: 0
    },
    legend: {
      show: false
    },
    stroke: {
      show: true,
      width: 2,
      curve: "smooth"
    },
    tooltip: {
      theme: "dark"
    }
  };
  const seriesmonthlychart = [{
    name: "Monthly Sales",
    data: [35, 60, 30, 55, 40]
  }];
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Card, {
    sx: {
      pb: 0,
      pl: 0,
      pr: 0
    },
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.CardContent, {
      sx: {
        paddingLeft: "30px",
        paddingRight: "30px"
      },
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Box, {
        display: "flex",
        alignItems: "flex-start",
        children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Box, {
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Typography, {
            variant: "h3",
            color: "textSecondary",
            sx: {
              marginBottom: "0"
            },
            gutterBottom: true,
            children: "Bonus"
          }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Typography, {
            variant: "h2",
            sx: {
              mt: "1px",
              mb: "0px"
            },
            gutterBottom: true,
            children: ["\u20A6", data && data.bonus_amount ? data.bonus_amount : "0"]
          }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Typography, {
            variant: "h4",
            sx: {
              mt: "12px",
              mb: "0px"
            },
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx("b", {
              children: "REFERRAL CODE:"
            }), " ", data && data.referral_code ? data.referral_code : ""]
          })]
        })
      })
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MonthlySales);

/***/ }),

/***/ 2209:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__);





const pricing = [{
  id: 1,
  badge: "none",
  package: "Buy Airtime",
  member: "3 Members",
  device: "Single Device",
  storage: "Free 100 on First",
  bkp: "X2 Your Recharge",
  btnsize: "large",
  btncolor: "secondary",
  btntext: "Airtime",
  btnlink: "/dashboards/purchase/airtime"
}, {
  id: 2,
  badge: "flex",
  package: "Buy Data",
  member: "5 Members",
  device: "Single Device",
  storage: "50MB Free on First",
  bkp: "Double Data",
  btnsize: "large",
  btncolor: "primary",
  btntext: "Data",
  btnlink: "/dashboards/purchase/data"
}];

const Pricing = () => {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
    container: true,
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
      item: true,
      xs: 12,
      lg: 12,
      sm: 12,
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
        variant: "h4",
        textAlign: "center",
        children: "What Service Do You Want?"
      })
    }), pricing.map(price => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
      item: true,
      xs: 12,
      lg: 6,
      sm: 6,
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Card, {
        sx: {
          textAlign: "center",
          overflow: "unset",
          position: "relative"
        },
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(next_link__WEBPACK_IMPORTED_MODULE_2__["default"], {
          href: price.btnlink,
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Button, {
            variant: "contained",
            size: price.btnsize,
            color: price.btncolor,
            sx: {
              width: "100%",
              mt: 4
            },
            children: price.btntext
          })
        })
      })
    }, price.id))]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Pricing);

/***/ }),

/***/ 7216:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5675);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _ThemeSelect__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7951);
/* harmony import */ var _baseCard_DashboardCard__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7802);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _assets_images_users_1_jpg__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7574);
/* harmony import */ var _assets_images_users_2_jpg__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(791);
/* harmony import */ var _assets_images_users_3_jpg__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6430);
/* harmony import */ var _assets_images_users_4_jpg__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(7326);
/* harmony import */ var _assets_images_users_5_jpg__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(8921);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(2245);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__);














const products = [{
  imgsrc: _assets_images_users_1_jpg__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z,
  name: 'Sunil Joshi',
  post: 'Web Designer',
  pname: 'Elite Admin',
  priority: 'Low',
  budget: '3.9'
}, {
  imgsrc: _assets_images_users_2_jpg__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z,
  name: 'Andrew McDownland',
  post: 'Project Manager',
  pname: 'Real Homes WP Theme',
  priority: 'Medium',
  budget: '24.5'
}, {
  imgsrc: _assets_images_users_3_jpg__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z,
  name: 'Christopher Jamil',
  post: 'Project Manager',
  pname: 'MedicalPro WP Theme',
  priority: 'High',
  budget: '12.8'
}, {
  imgsrc: _assets_images_users_4_jpg__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z,
  name: 'Nirav Joshi',
  post: 'Frontend Engineer',
  pname: 'Hosting Press HTML',
  priority: 'Critical',
  budget: '2.4'
}, {
  imgsrc: _assets_images_users_5_jpg__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z,
  name: 'Micheal Doe',
  post: 'Content Writer',
  pname: 'Helping Hands Theme',
  priority: 'Moderate',
  budget: '9.3'
}];

const ProductPerformance = ({
  data
}) => {
  const {
    0: open,
    1: setOpen
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
  const {
    0: openPinModal,
    1: setPinModal
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
  const {
    0: isloading,
    1: setIsloading
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true);
  const {
    0: transactionData,
    1: setTransactionData
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
  const {
    0: response,
    1: setResponse
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
  const {
    0: errorResponse,
    1: setErrorResponse
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    const currentUser = JSON.parse(localStorage.getItem("userData"));
    const token = localStorage.getItem("userToken"); // setAccessToken(token);
    // setUserData(currentUser);

    retrieveTransactionHistory(); // currentDate();
  }, []);

  const setEmptyAlert = () => {
    setResponse("");
    setErrorResponse("");
  };

  const retrieveTransactionHistory = () => {
    setIsloading(true);
    const headers = {
      Accept: "application/json" // Authorization: accessToken ? accessToken : "No Auth"

    };
    axios__WEBPACK_IMPORTED_MODULE_5___default()({
      method: 'post',
      url: 'https://mtn-backend-api-service.herokuapp.com/v1/auth/getTransaction',
      headers,
      data: {
        phone_number: data.phone_number,
        user_id: data._id
      }
    }).then(function (response) {
      console.log("this is the response data -->", response.data);
      setIsloading(false);

      if (response.data.statusCode === "000") {
        // setUserResponseData(response.data.payload);
        setTransactionData(response.data.data);
      } else {
        console.log("this is the response gotten", response);
      }
    }).catch(error => {
      setIsloading(false);
      console.log("this is the error response gotten", error);
      setErrorResponse("No Data for the User");
      setTimeout(setEmptyAlert, 5000);
    });
  };

  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_baseCard_DashboardCard__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
    title: "Transaction History",
    subtitle: "Ample Admin Vs Pixel Admin",
    customdisplay: "block",
    custommargin: "10px",
    action: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_ThemeSelect__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {}),
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, {
      sx: {
        overflow: 'auto',
        mt: -3
      },
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Table, {
        "aria-label": "simple table",
        sx: {
          whiteSpace: 'nowrap'
        },
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.TableHead, {
          children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.TableRow, {
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.TableCell, {
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                variant: "h5",
                children: "Reference ID"
              })
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.TableCell, {
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                variant: "h5",
                children: "Transaction Date"
              })
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.TableCell, {
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                variant: "h5",
                children: "Amount"
              })
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.TableCell, {
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                variant: "h5",
                children: "Description"
              })
            })]
          })
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.TableBody, {
          children: transactionData ? transactionData.map(transaction => /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.TableRow, {
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.TableCell, {
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                color: "textSecondary",
                variant: "h6",
                children: transaction.reference_id
              })
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.TableCell, {
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                color: "textSecondary",
                variant: "h6",
                children: moment__WEBPACK_IMPORTED_MODULE_11___default()(transaction.createdAt).format("MMMM, DD YYYY HH:mm:ss")
              })
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.TableCell, {
              children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                color: "textSecondary",
                variant: "h6",
                children: ["\u20A6", transaction.amount]
              })
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.TableCell, {
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                variant: "h6",
                children: transaction.description
              })
            })]
          }, transaction.id)) : "No Transaction Data"
        })]
      })
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProductPerformance);

/***/ }),

/***/ 3504:
/***/ ((__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) => {

/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var feather_icons_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(738);
/* harmony import */ var feather_icons_react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(feather_icons_react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8442);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material_styles__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5152);
/* harmony import */ var _baseCard_DashboardCard__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7802);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__);





const Chart = (0,next_dynamic__WEBPACK_IMPORTED_MODULE_4__["default"])(() => Promise.resolve(/* import() */).then(__webpack_require__.t.bind(__webpack_require__, 8403, 23)), {
  ssr: false,
  loadableGenerated: {
    webpack: () => [/*require.resolve*/(8403)],
    modules: ["..\\src\\components\\dashboard\\dashboard1\\SalesOverview.js -> " + "react-apexcharts"]
  }
});




const SalesOverview = () => {
  const theme = useTheme();
  const primary = theme.palette.primary.main;
  const secondary = theme.palette.secondary.main;
  const optionssalesoverview = {
    grid: {
      show: true,
      borderColor: 'transparent',
      strokeDashArray: 2,
      padding: {
        left: 0,
        right: 0,
        bottom: -13
      }
    },
    plotOptions: {
      bar: {
        horizontal: false,
        columnWidth: '42%',
        endingShape: 'rounded',
        borderRadius: 5
      }
    },
    colors: [primary, secondary],
    fill: {
      type: 'solid',
      opacity: 1
    },
    chart: {
      toolbar: {
        show: false
      },
      foreColor: '#adb0bb',
      fontFamily: "'DM Sans',sans-serif"
    },
    dataLabels: {
      enabled: false
    },
    markers: {
      size: 0
    },
    legend: {
      show: false
    },
    xaxis: {
      type: 'category',
      categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
      labels: {
        style: {
          cssClass: 'grey--text lighten-2--text fill-color'
        }
      }
    },
    yaxis: {
      show: true,
      min: 100,
      max: 400,
      tickAmount: 3
    },
    stroke: {
      show: true,
      width: 5,
      lineCap: 'butt',
      colors: ['transparent']
    },
    tooltip: {
      theme: 'dark'
    }
  };
  const seriessalesoverview = [{
    name: 'Ample Admin',
    data: [355, 390, 300, 350, 390, 180]
  }, {
    name: 'Pixel Admin',
    data: [280, 250, 325, 215, 250, 310]
  }];
  return /*#__PURE__*/_jsx(DashboardCard, {
    title: "Sales Overview",
    subtitle: "Ample Admin Vs Pixel Admin",
    customdisplay: "block",
    action: /*#__PURE__*/_jsxs(Stack, {
      direction: "row",
      spacing: 2,
      children: [/*#__PURE__*/_jsxs(Typography, {
        variant: "h6",
        display: "flex",
        alignItems: "center",
        sx: {
          color: () => theme.palette.primary.main
        },
        children: [/*#__PURE__*/_jsx(Typography, {
          sx: {
            color: 'primary.main',
            '& svg': {
              fill: () => theme.palette.primary.main
            },
            mr: '5px'
          },
          children: /*#__PURE__*/_jsx(FeatherIcon, {
            icon: "circle",
            width: "10",
            height: "10"
          })
        }), "Ample"]
      }), /*#__PURE__*/_jsxs(Typography, {
        variant: "h6",
        display: "flex",
        alignItems: "center",
        sx: {
          color: () => theme.palette.secondary.main
        },
        children: [/*#__PURE__*/_jsx(Typography, {
          sx: {
            color: 'secondary.main',
            '& svg': {
              fill: () => theme.palette.secondary.main
            },
            mr: '5px'
          },
          children: /*#__PURE__*/_jsx(FeatherIcon, {
            icon: "circle",
            width: "10",
            height: "10"
          })
        }), "Pixel Admin"]
      })]
    }),
    children: /*#__PURE__*/_jsx(Box, {
      children: /*#__PURE__*/_jsx(Chart, {
        options: optionssalesoverview,
        series: seriessalesoverview,
        type: "bar",
        height: "280px"
      })
    })
  });
};

/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (SalesOverview)));

/***/ }),

/***/ 486:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ SuccessToaster)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3590);
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8819);
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _styles_Component_module_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1726);
/* harmony import */ var _styles_Component_module_css__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_styles_Component_module_css__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_toastify__WEBPACK_IMPORTED_MODULE_1__]);
react_toastify__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];





function SuccessToaster({
  title
}) {
  react_toastify__WEBPACK_IMPORTED_MODULE_1__.toast.success( /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("p", {
    className: (_styles_Component_module_css__WEBPACK_IMPORTED_MODULE_4___default().toaster__content),
    children: title
  }), {
    toastId: 'oleefe__toaster__success'
  });
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(react_toastify__WEBPACK_IMPORTED_MODULE_1__.ToastContainer, {
    icon: true
  });
}
});

/***/ }),

/***/ 7951:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8442);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material_styles__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__);





const BootstrapInput = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_1__.experimentalStyled)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.InputBase)(({
  theme
}) => ({
  '&  .MuiInputBase-root': {
    borderRadius: '5px'
  },
  '& .MuiInputBase-input': {
    backgroundColor: theme.palette.mode === 'light' ? 'white' : theme.palette.grey.A400,
    borderRadius: 5,
    fontSize: 15,
    padding: '8px 33px 8px 16px',
    transition: theme.transitions.create(['border-color', 'box-shadow']),
    border: '1px solid rgba(0,0,0,0.12)'
  }
}));

const ThemeSelect = () => {
  const [age, setAge] = react__WEBPACK_IMPORTED_MODULE_0___default().useState('10');

  const handleChange = event => {
    setAge(event.target.value);
  };

  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Select, {
    labelId: "demo-simple-select-label",
    id: "demo-simple-select",
    value: age,
    onChange: handleChange,
    input: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(BootstrapInput, {}),
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.MenuItem, {
      value: 10,
      children: "March 2021"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.MenuItem, {
      value: 20,
      children: "April 2021"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.MenuItem, {
      value: 30,
      children: "May 2021"
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ThemeSelect);

/***/ }),

/***/ 4740:
/***/ ((__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) => {

/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8442);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material_styles__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5152);
/* harmony import */ var feather_icons_react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(738);
/* harmony import */ var feather_icons_react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(feather_icons_react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _ThemeSelect__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7951);
/* harmony import */ var _baseCard_DashboardCard__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7802);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__);




const Chart = (0,next_dynamic__WEBPACK_IMPORTED_MODULE_3__["default"])(() => Promise.resolve(/* import() */).then(__webpack_require__.t.bind(__webpack_require__, 8403, 23)), {
  ssr: false,
  loadableGenerated: {
    webpack: () => [/*require.resolve*/(8403)],
    modules: ["..\\src\\components\\dashboard\\dashboard1\\TotalSales.js -> " + "react-apexcharts"]
  }
});






const TotalSales = () => {
  const theme = useTheme();
  const primary = theme.palette.primary.main;
  const secondary = theme.palette.secondary.main;
  const warning = theme.palette.warning.main;
  const grey = theme.palette.grey.A100;
  const optionstotalsales = {
    labels: ['2021', '2020', '2019'],
    chart: {
      height: 280,
      type: 'donut',
      foreColor: '#adb0bb',
      fontFamily: 'DM sans'
    },
    colors: [primary, secondary, grey],
    dataLabels: {
      enabled: false
    },
    legend: {
      show: false
    },
    stroke: {
      colors: ['transparent']
    },
    plotOptions: {
      pie: {
        donut: {
          size: '78%',
          background: 'transparent',
          labels: {
            show: false,
            name: {
              show: true,
              fontSize: '18px',
              color: undefined,
              offsetY: -10
            },
            value: {
              show: false,
              color: '#98aab4'
            },
            total: {
              show: false,
              label: 'Our Visitors',
              color: '#98aab4'
            }
          }
        }
      }
    },
    tooltip: {
      theme: 'dark',
      fillSeriesColor: false
    }
  };
  const seriestotalsales = [25, 35, 35];
  return /*#__PURE__*/_jsxs(DashboardCard, {
    title: "Total Sales",
    subtitle: "Overview of Years",
    action: /*#__PURE__*/_jsx(ThemeSelect, {}),
    children: [/*#__PURE__*/_jsx(Divider, {
      style: {
        marginTop: '0px'
      }
    }), /*#__PURE__*/_jsxs(Box, {
      display: "flex",
      alignItems: "center",
      sx: {
        mt: 3
      },
      children: [/*#__PURE__*/_jsx(Typography, {
        color: "textSecondary",
        variant: "body1",
        sx: {
          fontSize: 'h5.fontSize'
        },
        children: "Sales Yearly"
      }), /*#__PURE__*/_jsx(Box, {
        sx: {
          ml: 'auto'
        },
        children: /*#__PURE__*/_jsx(Typography, {
          variant: "h2",
          fontWeight: "700",
          sx: {
            marginBottom: '0'
          },
          gutterBottom: true,
          children: "8,364,398"
        })
      })]
    }), /*#__PURE__*/_jsxs(Box, {
      sx: {
        mt: 5,
        position: 'relative'
      },
      children: [/*#__PURE__*/_jsx(Chart, {
        options: optionstotalsales,
        series: seriestotalsales,
        type: "donut",
        height: "280"
      }), /*#__PURE__*/_jsx(Typography, {
        color: "textSecondary",
        sx: {
          position: 'absolute',
          left: '46%',
          top: '45%'
        },
        children: /*#__PURE__*/_jsx(FeatherIcon, {
          icon: "shopping-cart",
          height: "30",
          width: "30"
        })
      })]
    }), /*#__PURE__*/_jsxs(Box, {
      display: "flex",
      justifyContent: "space-between",
      sx: {
        mt: 5
      },
      children: [/*#__PURE__*/_jsxs(Box, {
        display: "flex",
        alignItems: "center",
        children: [/*#__PURE__*/_jsx(Box, {
          sx: {
            backgroundColor: primary,
            borderRadius: '50%',
            height: 8,
            width: 8,
            mr: 1
          }
        }), /*#__PURE__*/_jsx(Typography, {
          color: "textSecondary",
          variant: "h6",
          children: "2021"
        })]
      }), /*#__PURE__*/_jsxs(Box, {
        display: "flex",
        alignItems: "center",
        children: [/*#__PURE__*/_jsx(Box, {
          sx: {
            backgroundColor: secondary,
            borderRadius: '50%',
            height: 8,
            width: 8,
            mr: 1
          }
        }), /*#__PURE__*/_jsx(Typography, {
          color: "textSecondary",
          variant: "h6",
          children: "2020"
        })]
      }), /*#__PURE__*/_jsxs(Box, {
        display: "flex",
        alignItems: "center",
        children: [/*#__PURE__*/_jsx(Box, {
          sx: {
            backgroundColor: warning,
            borderRadius: '50%',
            height: 8,
            width: 8,
            mr: 1
          }
        }), /*#__PURE__*/_jsx(Typography, {
          color: "textSecondary",
          variant: "h6",
          children: "2019"
        })]
      })]
    })]
  });
};

/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (TotalSales)));

/***/ }),

/***/ 8732:
/***/ ((__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) => {

/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var feather_icons_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(738);
/* harmony import */ var feather_icons_react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(feather_icons_react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5152);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8442);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_material_styles__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _baseCard_DashboardCard__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7802);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__);




const Chart = (0,next_dynamic__WEBPACK_IMPORTED_MODULE_3__["default"])(() => Promise.resolve(/* import() */).then(__webpack_require__.t.bind(__webpack_require__, 8403, 23)), {
  ssr: false,
  loadableGenerated: {
    webpack: () => [/*require.resolve*/(8403)],
    modules: ["..\\src\\components\\dashboard\\dashboard1\\WeeklyStats.js -> " + "react-apexcharts"]
  }
});




const options = (/* unused pure expression or super */ null && (['Action', 'Another Action', 'Something else here']));
const weeks = [{
  avatarbg: 'secondary.main',
  icon: 'shopping-cart',
  title: 'Top Sales',
  subtitle: 'Johnathan Doe',
  profit: '+68%'
}, {
  avatarbg: 'warning.main',
  icon: 'star',
  title: 'Best Seller',
  subtitle: 'MaterialPro Admin',
  profit: '+68%'
}, {
  avatarbg: 'success.main',
  icon: 'message-square',
  title: 'Most Commented',
  subtitle: 'Ample Admin',
  profit: '+68%'
}];

const WeeklyStats = () => {
  const [anchorEl, setAnchorEl] = React.useState(null);
  const open = Boolean(anchorEl);

  const handleClick = event => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  const theme = useTheme();
  const primary = theme.palette.primary.main; // chart

  const optionsweekstats = {
    chart: {
      height: 145,
      type: 'area',
      foreColor: '#adb0bb',
      fontFamily: 'DM sans',
      toolbar: {
        show: false
      },
      sparkline: {
        enabled: true
      }
    },
    colors: [primary],
    dataLabels: {
      enabled: false
    },
    stroke: {
      curve: 'smooth',
      width: 2
    },
    fill: {
      type: 'solid',
      opacity: 0.05
    },
    tooltip: {
      theme: 'dark'
    },
    grid: {
      show: false,
      padding: {
        right: 0,
        left: 0
      }
    }
  };
  const seriesweekstats = [{
    name: 'Weekly Stats',
    data: [40, 60, 50, 65]
  }];
  return /*#__PURE__*/_jsxs(DashboardCard, {
    title: "Weekly Stats",
    subtitle: "Average sales",
    custompadding: "0",
    customheaderpadding: "30px",
    action: /*#__PURE__*/_jsxs(Box, {
      children: [/*#__PURE__*/_jsx(Tooltip, {
        title: "Action",
        children: /*#__PURE__*/_jsx(IconButton, {
          "aria-expanded": open ? 'true' : undefined,
          "aria-haspopup": "true",
          onClick: handleClick,
          size: "large",
          "aria-label": "action",
          children: /*#__PURE__*/_jsx(FeatherIcon, {
            icon: "more-horizontal"
          })
        })
      }), /*#__PURE__*/_jsx(Menu, {
        id: "long-menu",
        MenuListProps: {
          'aria-labelledby': 'long-button'
        },
        anchorEl: anchorEl,
        open: open,
        onClose: handleClose,
        anchorOrigin: {
          vertical: 'bottom',
          horizontal: 'right'
        },
        transformOrigin: {
          vertical: 'top',
          horizontal: 'right'
        },
        children: options.map(option => /*#__PURE__*/_jsx(MenuItem, {
          selected: option === 'Pyxis',
          onClick: handleClose,
          children: option
        }, option))
      })]
    }),
    children: [/*#__PURE__*/_jsx(Box, {
      sx: {
        pl: '30px',
        pr: '30px'
      },
      children: weeks.map(week => /*#__PURE__*/_jsxs(Box, {
        display: "flex",
        alignItems: "center",
        sx: {
          mb: 3
        },
        children: [/*#__PURE__*/_jsx(Avatar, {
          sx: {
            backgroundColor: week.avatarbg,
            color: '#fff'
          },
          width: "45",
          children: /*#__PURE__*/_jsx(FeatherIcon, {
            icon: week.icon,
            width: "20"
          })
        }), /*#__PURE__*/_jsxs(Box, {
          sx: {
            ml: 2
          },
          children: [/*#__PURE__*/_jsx(Typography, {
            variant: "h5",
            fontWeight: "700",
            children: week.title
          }), /*#__PURE__*/_jsx(Typography, {
            color: "textSecondary",
            variant: "h6",
            fontWeight: "400",
            children: week.subtitle
          })]
        }), /*#__PURE__*/_jsx(Box, {
          sx: {
            ml: 'auto'
          },
          children: /*#__PURE__*/_jsx(Chip, {
            color: "default",
            size: "small",
            sx: {
              borderRadius: '6px',
              color: () => theme.palette.grey.A400
            },
            label: week.profit
          })
        })]
      }, week.title))
    }), /*#__PURE__*/_jsx(Box, {
      sx: {
        mt: 5,
        pt: 1
      },
      children: /*#__PURE__*/_jsx(Chart, {
        options: optionsweekstats,
        series: seriesweekstats,
        type: "area",
        height: "160"
      })
    })]
  });
};

/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (WeeklyStats)));

/***/ }),

/***/ 808:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5675);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1664);
/* harmony import */ var _assets_images_backgrounds_welcome_bg2_2x_svg_svg__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3429);
/* harmony import */ var _assets_images_backgrounds_people_png__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7803);
/* harmony import */ var _components_dashboard_dashboard1_ErrorToaster__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5732);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_dashboard_dashboard1_ErrorToaster__WEBPACK_IMPORTED_MODULE_6__]);
_components_dashboard_dashboard1_ErrorToaster__WEBPACK_IMPORTED_MODULE_6__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];










const WelcomeCard = ({
  data,
  time,
  clickAction
}) => /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Card, {
  elevation: 0,
  sx: {
    position: "relative"
  },
  children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, {
    className: "bg-img-1",
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(next_image__WEBPACK_IMPORTED_MODULE_1__["default"], {
      src: _assets_images_backgrounds_people_png__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z,
      alt: "welcome-img"
    })
  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.CardContent, {
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
      sx: {
        marginTop: "8px",
        marginBottom: "0px",
        lineHeight: "35px",
        position: "relative",
        zIndex: 9
      },
      variant: "h3",
      gutterBottom: true,
      children: [time ? time : 'Hey', " ", data && data.firstname ? data.firstname : 'User', ", ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("br", {})]
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
      variant: "h5",
      children: ["Welcome to ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("b", {
        children: "RightNet"
      })]
    }), data.isPin ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Button, {
      sx: {
        marginTop: "15px"
      },
      variant: "contained",
      color: "primary",
      onClick: clickAction,
      children: "Buy Airtime & Data Now!"
    }) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(next_link__WEBPACK_IMPORTED_MODULE_3__["default"], {
      href: "/dashboards/set-pin",
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Button, {
        sx: {
          marginTop: "15px"
        },
        variant: "contained",
        color: "primary",
        children: "Create Pin"
      })
    })]
  })]
});

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (WelcomeCard);
});

/***/ }),

/***/ 7735:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "zr": () => (/* reexport safe */ _WelcomeCard__WEBPACK_IMPORTED_MODULE_0__.Z),
/* harmony export */   "D1": () => (/* reexport safe */ _Earnings__WEBPACK_IMPORTED_MODULE_2__.Z),
/* harmony export */   "gI": () => (/* reexport safe */ _MonthlySales__WEBPACK_IMPORTED_MODULE_3__.Z),
/* harmony export */   "Cz": () => (/* reexport safe */ _ProductPerformance__WEBPACK_IMPORTED_MODULE_4__.Z),
/* harmony export */   "Ig": () => (/* reexport safe */ _EarningsShop__WEBPACK_IMPORTED_MODULE_9__.Z),
/* harmony export */   "nc": () => (/* reexport safe */ _Pricing__WEBPACK_IMPORTED_MODULE_11__.Z)
/* harmony export */ });
/* harmony import */ var _WelcomeCard__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(808);
/* harmony import */ var _BlogCard__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8372);
/* harmony import */ var _Earnings__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3457);
/* harmony import */ var _MonthlySales__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5997);
/* harmony import */ var _ProductPerformance__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7216);
/* harmony import */ var _SalesOverview__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3504);
/* harmony import */ var _TotalSales__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4740);
/* harmony import */ var _WeeklyStats__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8732);
/* harmony import */ var _DailyActivities__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(7025);
/* harmony import */ var _EarningsShop__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(3735);
/* harmony import */ var _MedicalProBranding__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(435);
/* harmony import */ var _Pricing__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(2209);
/* harmony import */ var _SuccessToaster__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(486);
/* harmony import */ var _ErrorToaster__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(5732);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_WelcomeCard__WEBPACK_IMPORTED_MODULE_0__, _ErrorToaster__WEBPACK_IMPORTED_MODULE_13__, _SuccessToaster__WEBPACK_IMPORTED_MODULE_12__]);
([_WelcomeCard__WEBPACK_IMPORTED_MODULE_0__, _ErrorToaster__WEBPACK_IMPORTED_MODULE_13__, _SuccessToaster__WEBPACK_IMPORTED_MODULE_12__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);















});

/***/ }),

/***/ 7803:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/people.d1f82f27.png","height":428,"width":582,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAYAAAD+Bd/7AAAAl0lEQVR42mMAgT3dlUwMuMDmtlK45IqW8tjJpdkzQOzFFbmMcEWXN6zkPzOvp2BaadbtSh+LKSCxZX3trAwgcPb0CbYpSYGnHt+8+frH168vv7x78/L///+uILk/P34wMxzZtpkbyJb5/PbNjP9///z/8enj/9sXz+8FKXj/9AkzAwz8///f7PeP703vXrzIKzCV9ISJAwDgSkdBhSqACQAAAABJRU5ErkJggg=="});

/***/ }),

/***/ 3429:
/***/ (() => {

/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/welcome-bg2-2x-svg.bb183002.svg","height":500,"width":522});

/***/ }),

/***/ 7988:
/***/ (() => {

/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/9mobile.2313db83.png","height":133,"width":90,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAUAAAAICAYAAAAx8TU7AAAAqElEQVR42mMwrkiQFswPvcqQHvZ/4/HgxF//xUQZhAtCT/Pmhx5pWBTpcfmJe9C9t55uDAzJYT82nXQLe/SZ4d22Mx6BDNmRpxkYskO/RHcHtX39zxXh3xLSypAV+ptBtTgikSE75D9DeOQ+hpzg/0rF4VUMIGBTnaghVxT8mzc/5Hl8XwsbAwjIFUWasuQF/5cqjMhmgAH5osi5ogVh93yaCzgZGBgYAJwdPIrJW/1xAAAAAElFTkSuQmCC"});

/***/ }),

/***/ 1547:
/***/ (() => {

/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/airtel.5cc6cb0c.png","height":489,"width":510,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA9ElEQVR42mN4FRHPwgACi5exXrdzKr2nY3DmgbzKo0euXlPf/P/PDJa7mV2g+9bW6eY7AbH/LxkY/j8C4heGJv+/zZxTz/Cwa4Lm94CwT98YWIESLP+vaurcOenhnXVXVOrI2+y8cww/kjNPfxSW+n9dQPj/RVuHifcXLONgAIIPXn4hT20dlzM8tLLffV5R5fEJ/yBnkMR7BgawvS8dXJvu6hmaMjD4+rCDBP74BSe+0DW4BmK/trJze2RsEcUAA/8r6vlfmFl9vyKn4P3S2V3nkYmFP1jc0YORAQTuWdqJXLew7nrg4699z9hMGyzpGQCWBADS6mCH0IwuzwAAAABJRU5ErkJggg=="});

/***/ }),

/***/ 8343:
/***/ (() => {

/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/glo.276fb447.png","height":128,"width":128,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA/klEQVR42mMAgQtXpvBNPJI8p+WQ3/1N13puXHm6vYkBBjoT6jiTN/udctpu/j9qT/j/3tNN/7fcWv5/5umcDQwgYNlt0+m/Nfh/yvbMn/OOz/1Xc6Dmb+HR4l8Fu6P/d64IzWVgiGW4MG/nvP8zVs/4u37/hv8bDm/4P2PzrD+ztk3/n97vvIWBOZTh+MxdU/5vOL7279pja/7P2TX7/8Id83/3b+j6nzLLaw2DmoF6odMkrf/Lrs3+Xb+/5I/9KqXfmdsi/qeuDvifOjM0gAEE9Ny0FwZOdvwfsd72f+xm1/9hyxz+x0z1bmBABYzRJsE6i80Tdefq2ep6wkQBp/J7vRXIEg0AAAAASUVORK5CYII="});

/***/ }),

/***/ 6989:
/***/ (() => {

/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/mtn.2b9ac471.png","height":76,"width":139,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAECAYAAACzzX7wAAAAfklEQVR4nA3NPQ7CMAwG0M+JEzK0DEhsFTBRIW7A1CNwbVYWVmZ+VtTGtU23tz06ditOjEtOUJk9usOYKVTBBOBGp325wu0uM4a2CabquUp8x6gPM+zofCgD4L8qvm2b+F2cxxGbEPxlRpX6riAl9MxYm1oBkQXCtHQfd3r+AXi1Nr6FyxXKAAAAAElFTkSuQmCC"});

/***/ }),

/***/ 1971:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/utility.aa290b79.png","height":108,"width":100,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAcAAAAICAQAAACfDS2NAAAAf0lEQVR42mOwZXBlsLcwbbdy0WGwZGBwUrVxdFI2SLAyt3a3NmCwXGDnK2SmPEerzTLVdgGDo5Ohn8pmyaPKG8wiHB0Z7E1bWZQXSWwVW6/ObqfNYJPvoK9bYNyoXGrsZjOTwSTBMsxV1bDKRcMi1XACAwhYOBvvNw9mYDBgAADiGR1l6ZHBjQAAAABJRU5ErkJggg=="});

/***/ }),

/***/ 8921:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/5.743e9817.jpg","height":200,"width":200,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAgACAMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABwEBAAAAAAAAAAAAAAAAAAAAA//aAAwDAQACEAMQAAAAoIBP/8QAHhAAAQEJAAAAAAAAAAAAAAAAERQAAwQSExUhMZH/2gAIAQEAAT8AWxFxpl0mImOTodb/xAAaEQACAgMAAAAAAAAAAAAAAAABAgQSABRx/9oACAECAQE/AIRZ9qxJrIZRwZ//xAAZEQEAAgMAAAAAAAAAAAAAAAABABEDEyP/2gAIAQMBAT8AzUaqA5k//9k="});

/***/ })

};
;