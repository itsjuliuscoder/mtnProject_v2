"use strict";
exports.id = 382;
exports.ids = [382];
exports.modules = {

/***/ 9382:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var feather_icons_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(738);
/* harmony import */ var feather_icons_react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(feather_icons_react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _custom_elements_CustomTextField__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1472);
/* harmony import */ var _custom_elements_CustomSelect__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9379);
/* harmony import */ var _custom_elements_CustomRadio__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2373);
/* harmony import */ var _custom_elements_CustomFormLabel__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5959);
/* harmony import */ var react_spinners_MoonLoader__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6729);
/* harmony import */ var react_spinners_MoonLoader__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_spinners_MoonLoader__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _dashboard_dashboard1_ErrorToaster__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5732);
/* harmony import */ var _dashboard_dashboard1_SuccessToaster__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(486);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_dashboard_dashboard1_SuccessToaster__WEBPACK_IMPORTED_MODULE_9__, _dashboard_dashboard1_ErrorToaster__WEBPACK_IMPORTED_MODULE_8__]);
([_dashboard_dashboard1_SuccessToaster__WEBPACK_IMPORTED_MODULE_9__, _dashboard_dashboard1_ErrorToaster__WEBPACK_IMPORTED_MODULE_8__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);














const currencies = [{
  value: 'female',
  label: 'Female'
}, {
  value: 'male',
  label: 'Male'
}, {
  value: 'other',
  label: 'Other'
}];
const countries = [{
  value: 'india',
  label: 'India'
}, {
  value: 'uk',
  label: 'United Kingdom'
}, {
  value: 'srilanka',
  label: 'Srilanka'
}];

const FbBasicHeaderForm = () => {
  const Router = (0,next_router__WEBPACK_IMPORTED_MODULE_11__.useRouter)();
  const [currency, setCurrency] = react__WEBPACK_IMPORTED_MODULE_0___default().useState('');

  const handleChange2 = event => {
    setCurrency(event.target.value);
  };

  const [selectedValue, setSelectedValue] = react__WEBPACK_IMPORTED_MODULE_0___default().useState('');
  const [pin, setPin] = react__WEBPACK_IMPORTED_MODULE_0___default().useState('');
  const [rPin, setRPin] = react__WEBPACK_IMPORTED_MODULE_0___default().useState('');
  const {
    0: isloading,
    1: setIsloading
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
  const {
    0: response,
    1: setResponse
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
  const {
    0: errorResponse,
    1: setErrorResponse
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
  const {
    0: userData,
    1: setUserData
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)("");
  const {
    0: accessToken,
    1: setAccessToken
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');

  const handleChange3 = event => {
    setSelectedValue(event.target.value);
  };

  const [country, setCountry] = react__WEBPACK_IMPORTED_MODULE_0___default().useState('');

  const handleChange4 = event => {
    setCountry(event.target.value);
  };

  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    const currentUser = JSON.parse(localStorage.getItem("userData"));
    const token = localStorage.getItem("userToken");
    setAccessToken(token);
    setUserData(currentUser);
  }, []);

  const handleSubmit = e => {
    setIsloading(true);
    e.preventDefault();
    console.log("this are the data -->", pin, rPin);
    const headers = {
      Accept: "application/json",
      Authorization: accessToken ? accessToken : "No Auth"
    };

    if (pin == rPin) {
      axios__WEBPACK_IMPORTED_MODULE_10___default()({
        method: 'post',
        url: 'https://mtn-backend-api-service.herokuapp.com/v1/auth/create_transactionPin',
        headers,
        data: {
          phone_number: userData.phone_number,
          user_id: userData._id,
          pin: rPin
        }
      }).then(function (response) {
        console.log("this is the response data -->", response.data);
        setIsloading(false);

        if (response.data.statusCode === "000") {
          setResponse(response.data.statusMessage);
          setTimeout(() => {
            Router.replace("/authentication/login");
          }, 4000);
        } else {
          console.log("this is the response gotten", response);
          setErrorResponse("Unable to create PIN");
        }
      }).catch(error => {
        setIsloading(false);
        console.log("this is the error response gotten");
        setErrorResponse("Unable to create PIN");
        setTimeout(setEmptyAlert, 5000);
      });
    } else {
      setErrorResponse("PIN Do not Match");
    }
  };

  react__WEBPACK_IMPORTED_MODULE_0___default().useEffect(() => {
    setTimeout(() => setIsloading(false), 3000);
  });

  const setEmptyAlert = () => {
    setResponse("");
    setErrorResponse("");
  };

  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx("div", {
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Card, {
      sx: {
        p: 0
      },
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
        sx: {
          padding: '15px 30px'
        },
        display: "flex",
        alignItems: "center",
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
          flexGrow: 1,
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
            fontWeight: "500",
            variant: "h4",
            children: "Create Transaction PIN"
          })
        })
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Divider, {}), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
        display: "flex",
        alignItems: "center",
        p: 2,
        sx: {
          backgroundColor: 'primary.light',
          color: 'primary.main'
        },
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx((feather_icons_react__WEBPACK_IMPORTED_MODULE_2___default()), {
          icon: "alert-circle",
          width: "18"
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
          sx: {
            ml: 1
          },
          children: "This PIN will be used to buy Airtime and Data"
        })]
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)("form", {
        onSubmit: handleSubmit,
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.CardContent, {
          sx: {
            padding: '30px'
          },
          children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
            container: true,
            spacing: 3,
            children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
              item: true,
              lg: 6,
              md: 12,
              sm: 12,
              xs: 12,
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_custom_elements_CustomFormLabel__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                sx: {
                  mt: 0
                },
                htmlFor: "city-text",
                children: "Enter PIN"
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_custom_elements_CustomTextField__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                type: "password",
                placeholder: "Enter PIN",
                name: "rPin",
                id: "rPin",
                variant: "outlined",
                fullWidth: true,
                required: true,
                value: rPin,
                onChange: e => setRPin(e.target.value),
                size: "small"
              })]
            }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
              item: true,
              lg: 6,
              md: 12,
              sm: 12,
              xs: 12,
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_custom_elements_CustomFormLabel__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                sx: {
                  mt: 0
                },
                htmlFor: "state-text",
                children: "Enter PIN Again"
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_custom_elements_CustomTextField__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                type: "password",
                placeholder: "Enter PIN",
                name: "pin",
                id: "pin",
                variant: "outlined",
                fullWidth: true,
                required: true,
                value: pin,
                onChange: e => setPin(e.target.value),
                size: "small"
              })]
            })]
          })
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Divider, {}), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
          p: 3,
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Button, {
            variant: "contained",
            color: "error",
            sx: {
              mr: 1
            },
            children: "Cancel"
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Button, {
            type: "submit",
            variant: "contained",
            color: "primary",
            onClick: () => setIsloading(!isloading),
            children: isloading ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx((react_spinners_MoonLoader__WEBPACK_IMPORTED_MODULE_7___default()), {
              color: "#fff",
              loading: isloading,
              size: 30
            }) : 'Create Pin'
          })]
        })]
      }), errorResponse && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_dashboard_dashboard1_ErrorToaster__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
        title: errorResponse
      }), response && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_dashboard_dashboard1_SuccessToaster__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
        title: response
      })]
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (FbBasicHeaderForm);
});

/***/ })

};
;