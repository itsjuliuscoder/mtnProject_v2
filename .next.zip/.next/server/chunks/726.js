exports.id = 726;
exports.ids = [726];
exports.modules = {

/***/ 1726:
/***/ ((module) => {

// Exports
module.exports = {
	"banner_bg": "Component_banner_bg__8Ohz9",
	"row__steps": "Component_row__steps__9wI5T",
	"step_one": "Component_step_one__BTed5",
	"step_two": "Component_step_two__LyYQy",
	"step_three": "Component_step_three__Odkyq",
	"step_four": "Component_step_four__xm_4G",
	"btn__register": "Component_btn__register__svfpJ",
	"footer__row": "Component_footer__row__WX6GD",
	"container__style": "Component_container__style__8D_nB",
	"top2": "Component_top2__uqmrA",
	"never__runout": "Component_never__runout__w0QYs",
	"never__runout_text": "Component_never__runout_text__odHA9",
	"never__runout_text__2": "Component_never__runout_text__2__8b09H",
	"never__runout_text__2_2": "Component_never__runout_text__2_2__4GqkT",
	"never__runout_text__2_3": "Component_never__runout_text__2_3__WhOZb",
	"never__runout_text__2_4": "Component_never__runout_text__2_4__WkD8C",
	"never__runout_text__2_5": "Component_never__runout_text__2_5__QHKD_",
	"never__runout_text__2_6": "Component_never__runout_text__2_6__YVmv0",
	"never__runout_text__2_7": "Component_never__runout_text__2_7__H1CFS",
	"never__runout_text__3": "Component_never__runout_text__3__LhXbA",
	"getting__started": "Component_getting__started__SeFxs",
	"row__style": "Component_row__style__iioqC",
	"row__style__2": "Component_row__style__2__Ju_il",
	"row__style__3": "Component_row__style__3__qndzz",
	"create__account": "Component_create__account__qs3qN",
	"inner__row": "Component_inner__row__o7G6s",
	"btn__center": "Component_btn__center__k_HKH",
	"group__btn": "Component_group__btn__f5zB3",
	"create__account__3": "Component_create__account__3__V3JGt",
	"create__account__4": "Component_create__account__4__qZl6_",
	"create__account__2": "Component_create__account__2__aKdOs",
	"toaster__content": "Component_toaster__content__70cQV",
	"row__line": "Component_row__line___su_F",
	"paystack__button": "Component_paystack__button__ON7tb",
	"input__field": "Component_input__field__Votk1",
	"modal___window": "Component_modal___window__10ZmA",
	"modal___window__3": "Component_modal___window__3__J5whT",
	"modal___window_1": "Component_modal___window_1__B5c8X"
};


/***/ })

};
;